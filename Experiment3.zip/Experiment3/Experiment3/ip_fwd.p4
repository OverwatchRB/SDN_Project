// ip_fwd.p4 - IP forwarding for OneBigSwitch (obs/s3)
// Handles packets with etherType=0x1234 (INT header present)
// and standard 0x0800 packets.
#include <core.p4>
#include <v1model.p4>

typedef bit<48> macAddr_t;
typedef bit<9>  egressSpec_t;

header ethernet_t {
    macAddr_t dstAddr;
    macAddr_t srcAddr;
    bit<16>   etherType;
}

header int_t {
    bit<16> hop_cnt;
    bit<48> cum_total_delay;
    bit<48> cum_queue_delay;
    bit<48> cum_proc_delay;
    bit<16> msg_id;
    bit<16> reserved;
}

header ipv4_t {
    bit<4>  version;
    bit<4>  ihl;
    bit<8>  diffserv;
    bit<16> totalLen;
    bit<16> identification;
    bit<3>  flags;
    bit<13> fragOffset;
    bit<8>  ttl;
    bit<8>  protocol;
    bit<16> hdrChecksum;
    bit<32> srcAddr;
    bit<32> dstAddr;
}

header udp_t {
    bit<16> srcPort;
    bit<16> dstPort;
    bit<16> length;
    bit<16> checksum;
}

struct metadata { }

struct headers {
    ethernet_t ethernet;
    int_t      int_hdr;
    ipv4_t     ipv4;
    udp_t      udp;
}

parser MyParser(packet_in packet,
                out headers hdr,
                inout metadata meta,
                inout standard_metadata_t stdmeta) {
    state start {
        packet.extract(hdr.ethernet);
        transition select(hdr.ethernet.etherType) {
            0x1234: parse_int;
            0x0800: parse_ipv4;
            default: accept;
        }
    }
    state parse_int {
        packet.extract(hdr.int_hdr);
        transition parse_ipv4;
    }
    state parse_ipv4 {
        packet.extract(hdr.ipv4);
        transition select(hdr.ipv4.protocol) {
            17: parse_udp;
            default: accept;
        }
    }
    state parse_udp {
        packet.extract(hdr.udp);
        transition accept;
    }
}

control MyVerifyChecksum(inout headers hdr, inout metadata meta) { apply { } }

control MyIngress(inout headers hdr,
                  inout metadata meta,
                  inout standard_metadata_t stdmeta) {
    action forward(egressSpec_t port) {
        stdmeta.egress_spec = port;
    }
    action drop() {
        mark_to_drop(stdmeta);
    }
    table ip_table {
        key = { hdr.ipv4.dstAddr: exact; }
        actions = { forward; drop; }
        size = 1024;
        default_action = drop();
    }
    apply {
        if (hdr.ipv4.isValid()) {
            ip_table.apply();
        }
    }
}

control MyEgress(inout headers hdr, inout metadata meta,
                 inout standard_metadata_t stdmeta) { apply { } }

control MyComputeChecksum(inout headers hdr, inout metadata meta) { apply { } }

control MyDeparser(packet_out packet, in headers hdr) {
    apply {
        packet.emit(hdr.ethernet);
        packet.emit(hdr.int_hdr);   // only emits if valid (0x1234 packets)
        packet.emit(hdr.ipv4);
        packet.emit(hdr.udp);
        // payload appended automatically by bmv2
    }
}

V1Switch(MyParser(), MyVerifyChecksum(), MyIngress(), MyEgress(),
         MyComputeChecksum(), MyDeparser()) main;
