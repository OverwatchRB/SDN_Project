#!/usr/bin/env python3
"""
Usage:
  python3 plot_results_mean.py results_h3_d4_* --out plot_mean.png
"""

import os
import re
import argparse
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

STRATEGIES = ["root", "subtree_cover", "uniform"]

STRATEGY_STYLE = {
    "root":          {"color": "#d62728", "marker": "s", "label": "Root"},
    "subtree_cover": {"color": "#1f77b4", "marker": "o", "label": "Subtree Cover"},
    "uniform":       {"color": "#2ca02c", "marker": "^", "label": "Uniform"},
}

RE_FOLDER = re.compile(
    r"results"
    r"_h(?P<h>\d+)_d(?P<d>\d+)_k(?P<k>\d+)"
    r"_(?P<placement>root|subtree_cover|uniform)"
    r"_\d{8}_\d{6}"
)

RE_DWS_MEAN = re.compile(r"DWS.*?mean\s*:\s*([\d\.]+)\s*us", re.DOTALL)
RE_OML_MEAN = re.compile(r"OML.*?mean\s*:\s*([\d\.]+)\s*us", re.DOTALL)


def parse_summary_file(path):
    try:
        with open(path) as f:
            text = f.read()
    except OSError:
        return None
    dws_mean = RE_DWS_MEAN.search(text)
    oml_mean = RE_OML_MEAN.search(text)
    if not (dws_mean and oml_mean):
        return None
    return (float(dws_mean.group(1)), float(oml_mean.group(1)))


def parse_folder_name(folder_name):
    m = RE_FOLDER.match(os.path.basename(folder_name))
    if m:
        return (int(m.group("h")), int(m.group("d")),
                int(m.group("k")), m.group("placement"))
    return None


def collect_best_by_oml_mean(input_dirs):
    groups = defaultdict(list)

    for dpath in input_dirs:
        dpath  = dpath.rstrip("/")
        parsed = parse_folder_name(dpath)
        if not parsed:
            print(f"  [skip] Unrecognised folder name: {os.path.basename(dpath)}")
            continue
        h, d, k, placement = parsed
        stats = parse_summary_file(os.path.join(dpath, "summary.txt"))
        if stats is None:
            print(f"  [warn] No valid summary.txt in: {os.path.basename(dpath)}")
            continue
        groups[(k, placement)].append((stats, dpath))

    if not groups:
        return {p: {} for p in STRATEGIES}

    all_k    = {k for (k, _) in groups}
    pooled_k = {min(all_k), max(all_k)}
    print(f"  Detected k range : {sorted(all_k)}")
    print(f"  Pooled k (shared): {sorted(pooled_k)}\n")

    best = {p: {} for p in STRATEGIES}

    # min/max k: pool all placements, pick single best, assign to all
    pooled_groups = defaultdict(list)
    for (k, placement), items in groups.items():
        if k in pooled_k:
            pooled_groups[k].extend(items)

    for k, items in sorted(pooled_groups.items()):
        best_stats, best_path = min(items, key=lambda x: x[0][1])  # min oml_mean
        for placement in STRATEGIES:
            best[placement][k] = best_stats
        print(f"  k={k:2d}  [all placements]  "
              f"DWS mean={best_stats[0]:.1f} us  OML mean={best_stats[1]:.1f} us  "
              f"(from {os.path.basename(best_path)})")

    # All other k: best per (k, placement) independently
    for (k, placement), items in sorted(groups.items()):
        if k in pooled_k:
            continue
        best_stats, best_path = min(items, key=lambda x: x[0][1])
        best[placement][k] = best_stats
        print(f"  k={k:2d}  {placement:15s}  "
              f"DWS mean={best_stats[0]:.1f} us  OML mean={best_stats[1]:.1f} us  "
              f"(from {os.path.basename(best_path)})")

    return best


def plot(best, out_path):
    fig, axes = plt.subplots(1, 2, figsize=(14, 5), sharex=True)

    for placement in STRATEGIES:
        data = best[placement]
        if not data:
            continue
        ks       = sorted(data.keys())
        dws_mean = [data[k][0] / 1000 for k in ks]
        oml_mean = [data[k][1] / 1000 for k in ks]

        style = STRATEGY_STYLE[placement]
        axes[0].plot(ks, dws_mean, marker=style["marker"], color=style["color"],
                     linewidth=2, markersize=8, label=style["label"])
        axes[1].plot(ks, oml_mean, marker=style["marker"], color=style["color"],
                     linewidth=2, markersize=8, label=style["label"])

    axes[0].set_title("max − min recv timestamp\nacross receivers (mean)", fontsize=9, fontweight='normal')
    axes[1].set_title("max e2e latency\nacross receivers (mean)",          fontsize=9, fontweight='normal')

    for ax in axes:
        ax.set_xlabel("Budget (k)", fontsize=12)
        ax.set_ylabel("Duration (ms)", fontsize=12)
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
        ax.grid(True, linestyle="--", alpha=0.45)
        ax.legend(fontsize=10)

    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    print(f"\nPlot saved → {out_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Plot DWS/OML mean from results_h*_d*_k*_<placement>_* folders."
    )
    parser.add_argument("dirs", nargs="+",
        help="One or more results_h..._d..._k..._<placement>_<timestamp> folder paths")
    parser.add_argument("--out", default="plot_mean.png",
        help="Output PNG filename (default: plot_mean.png)")
    args = parser.parse_args()

    print(f"Processing {len(args.dirs)} folder(s):")
    best = collect_best_by_oml_mean(args.dirs)

    total = sum(len(best[p]) for p in STRATEGIES)
    if total == 0:
        print("No valid data found. Exiting.")
        return

    print(f"\nLoaded {total} data point(s). Plotting...")
    plot(best, args.out)


if __name__ == "__main__":
    main()
