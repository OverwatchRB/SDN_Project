#!/usr/bin/env python3

import argparse
import socket
import struct
import time

from scapy.all import Ether, IP, UDP, Raw


SRC_MAC   = '00:00:00:00:00:01'
SRC_IP    = '10.0.0.1'
BCAST_MAC = 'ff:ff:ff:ff:ff:ff'
BCAST_IP  = '10.255.255.255'
SRC_PORT  = 12345
DST_PORT  = 12345
ETYPE_INT = 0x1234

TS_OFFSET = 14 + 24 + 20 + 8   # Ethernet(14) + INT(24) + IPv4(20) + UDP(8)


def build_template(msg_id: int, dst_mac: str, dst_ip: str) -> bytearray:
    """
    Build a packet template for one child.
    Timestamp field is left as 0 and stamped in-place at send time.
    """
    int_header = (
        struct.pack('>H', 0)      +   # hop_cnt + padding
        struct.pack('>Q', 0)[2:]  +   # cum_total_delay (6 bytes)
        struct.pack('>Q', 0)[2:]  +   # cum_queue_delay (6 bytes)
        struct.pack('>Q', 0)[2:]  +   # cum_proc_delay  (6 bytes)
        struct.pack('>H', msg_id) +   # msg_id
        struct.pack('>H', 0)          # reserved
    )
    payload   = struct.pack('>Q', 0)  # send_ts placeholder
    eth       = Ether(src=SRC_MAC, dst=dst_mac, type=ETYPE_INT)
    ipv4      = IP(src=SRC_IP, dst=dst_ip, proto=17)
    udp       = UDP(sport=SRC_PORT, dport=DST_PORT)
    raw       = Raw(load=payload)
    pkt_bytes = bytes(eth) + int_header + bytes(ipv4 / udp / raw)
    return bytearray(pkt_bytes)


def main():
    parser = argparse.ArgumentParser(
        description='Sender — per-child iface forwarding (root/leaf)'
    )
    parser.add_argument('--cycles',          type=int,   default=100)
    parser.add_argument('--gap',             type=float, default=0.0,
                        help='Gap between cycles in milliseconds')
    parser.add_argument('--children-macs',   required=True,
                        help='Comma-separated MAC per child')
    parser.add_argument('--children-ips',    required=True,
                        help='Comma-separated IP per child; empty string '
                             'for direct switch children (broadcast)')
    parser.add_argument('--children-ifaces', required=True,
                        help='Comma-separated iface per child')
    args = parser.parse_args()

    children_macs   = args.children_macs.split(',')
    children_ips    = args.children_ips.split(',')
    children_ifaces = args.children_ifaces.split(',')

    if not (len(children_macs) == len(children_ips) == len(children_ifaces)):
        raise ValueError(
            '--children-macs, --children-ips, --children-ifaces '
            'must all have the same number of entries'
        )

    children = list(zip(children_macs, children_ips, children_ifaces))

    print(f'[sender] root/leaf sender starting.')
    print(f'  cycles : {args.cycles}')
    print(f'  gap    : {args.gap} ms')
    print(f'  children:')
    for mac, ip, iface in children:
        mode = f'OBS -> {ip}' if ip else 'direct broadcast'
        print(f'    mac={mac}  iface={iface}  {mode}')

    # Open one raw socket per unique outgoing interface
    unique_ifaces = set(iface for _, _, iface in children)
    raw_socks = {}
    for iface in unique_ifaces:
        s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
        s.bind((iface, 0))
        raw_socks[iface] = s

    # Pre-build one template per (msg_id, child) pair
    # For direct children: broadcast MAC/IP template
    # For OBS children: unicast MAC/IP template
    print(f'Pre-building {args.cycles} x {len(children)} packet templates ...')
    templates = []
    for msg_id in range(args.cycles):
        per_child = []
        for dst_mac, dst_ip, iface in children:
            if dst_ip:
                # OBS path: unicast to specific dst
                tmpl = build_template(msg_id, dst_mac, dst_ip)
            else:
                # Direct path: broadcast
                tmpl = build_template(msg_id, BCAST_MAC, BCAST_IP)
            per_child.append((tmpl, iface))
        templates.append(per_child)

    print('Templates ready. Sending ...')

    total_sent = 0
    for msg_id, per_child in enumerate(templates):
        # ONE timestamp for this msg_id — all children share the same reference
        ts = int(time.time() * 1_000_000)
        for tmpl, iface in per_child:
            struct.pack_into('>Q', tmpl, TS_OFFSET, ts)
            raw_socks[iface].send(bytes(tmpl))
            total_sent += 1
        if args.gap > 0:
            time.sleep(args.gap / 1000.0)

    print(f'[sender] Done. Sent {total_sent} packets over {args.cycles} cycles.')

    for s in raw_socks.values():
        s.close()


if __name__ == '__main__':
    main()
