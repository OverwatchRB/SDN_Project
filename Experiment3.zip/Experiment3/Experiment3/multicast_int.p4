#include <core.p4>
#include <v1model.p4>

typedef bit<9>  egressSpec_t;
typedef bit<48> macAddr_t;

header ethernet_t {
    macAddr_t dstAddr;
    macAddr_t srcAddr;
    bit<16>   etherType;
}

header int_t {
    bit<16> hop_cnt;
    bit<48> cum_total_delay;   // sum of (egress_ts - ingress_ts)
    bit<48> cum_queue_delay;   // sum of deq_timedelta
    bit<48> cum_proc_delay;    // sum of (total - queue)
    bit<16> msg_id;
    bit<16> reserved;
}

header ipv4_t {
    bit<4>  version;
    bit<4>  ihl;
    bit<8>  diffserv;
    bit<16> total_len;
    bit<16> identification;
    bit<3>  flags;
    bit<13> frag_offset;
    bit<8>  ttl;
    bit<8>  protocol;
    bit<16> hdr_checksum;
    bit<32> src_addr;
    bit<32> dst_addr;
}

header udp_t {
    bit<16> src_port;
    bit<16> dst_port;
    bit<16> length;
    bit<16> checksum;
}

struct metadata {
    bit<48> ingress_ts;
}

struct headers {
    ethernet_t ethernet;
    int_t      int_hdr;
    ipv4_t     ipv4;
    udp_t      udp;
}

parser MyParser(packet_in packet,
                out headers hdr,
                inout metadata meta,
                inout standard_metadata_t standard_metadata) {

    state start {
        packet.extract(hdr.ethernet);
        transition select(hdr.ethernet.etherType) {
            0x1234: parse_int;
            default: parse_ipv4;
        }
    }
    state parse_int {
        packet.extract(hdr.int_hdr);
        transition parse_ipv4;
    }
    state parse_ipv4 {
        packet.extract(hdr.ipv4);
        transition parse_udp;
    }
    state parse_udp {
        packet.extract(hdr.udp);
        transition accept;
    }
}

control MyVerifyChecksum(inout headers hdr, inout metadata meta) {
    apply { }
}

control MyIngress(inout headers hdr,
                  inout metadata meta,
                  inout standard_metadata_t standard_metadata) {

    action drop() {
        mark_to_drop(standard_metadata);
    }

    action multicast() {
        standard_metadata.mcast_grp = 1;
    }

    action mac_forward(egressSpec_t port) {
        standard_metadata.egress_spec = port;
    }

    table mac_lookup {
        key = { hdr.ethernet.dstAddr : exact; }
        actions = { multicast; mac_forward; drop; }
        size = 1024;
        default_action = multicast;
    }

    apply {
        meta.ingress_ts = standard_metadata.ingress_global_timestamp;
        if (hdr.int_hdr.isValid()) {
            hdr.int_hdr.hop_cnt = hdr.int_hdr.hop_cnt + 1;
        }
        if (hdr.ethernet.isValid()) {
            mac_lookup.apply();
        }
    }
}

control MyEgress(inout headers hdr,
                 inout metadata meta,
                 inout standard_metadata_t standard_metadata) {

    action drop() {
        mark_to_drop(standard_metadata);
    }

    apply {
        // Avoid sending back to ingress port
        if (standard_metadata.egress_port == standard_metadata.ingress_port) {
            drop();
        }
        if (hdr.int_hdr.isValid()) {
            // Total per‑hop delay
            bit<48> total = standard_metadata.egress_global_timestamp - meta.ingress_ts;
            // Queueing delay (deq_timedelta is 32‑bit)
            bit<48> queue = (bit<48>) standard_metadata.deq_timedelta;
            // Processing delay = total - queue
            bit<48> proc = total - queue;

            hdr.int_hdr.cum_total_delay = hdr.int_hdr.cum_total_delay + total;
            hdr.int_hdr.cum_queue_delay = hdr.int_hdr.cum_queue_delay + queue;
            hdr.int_hdr.cum_proc_delay  = hdr.int_hdr.cum_proc_delay + proc;
        }
    }
}

control MyComputeChecksum(inout headers hdr, inout metadata meta) {
    apply { }
}

control MyDeparser(packet_out packet, in headers hdr) {
    apply {
        packet.emit(hdr.ethernet);
        packet.emit(hdr.int_hdr);    // emits only if valid
        packet.emit(hdr.ipv4);
        packet.emit(hdr.udp);
        // payload is automatically emitted
    }
}

V1Switch(MyParser(), MyVerifyChecksum(), MyIngress(), MyEgress(),
         MyComputeChecksum(), MyDeparser()) main;
