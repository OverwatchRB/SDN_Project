#!/usr/bin/env python3
"""
hybrid_topo.py
==============
Hybrid multicast tree experiment — root, leaf, subtree_cover, uniform.

h0 connectivity rules:
  root k>0      : h0 → sw_l0_p0 directly (no OBS link)
  root k=0      : h0 → OBS (pure software proxy tree)
  leaf          : h0 → direct links for switch children, OBS for proxy children
  subtree_cover : same link logic as leaf/uniform
  uniform       : same link logic as leaf/uniform

Metrics:
  DWS : max(recv_ts_us) - min(recv_ts_us) per message across all receivers
  OML : max(e2e_us) per message across all receivers

Results saved to timestamped folder: results_h<h>_d<d>_k<k>_<placement>_<ts>/
"""

import argparse
import csv
import os
import subprocess
import time
from collections import defaultdict
from datetime import datetime

from mininet.topo import Topo
from mininet.net import Mininet
from mininet.log import setLogLevel
from mininet.cli import CLI
from p4_mininet import P4Switch, P4Host

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SW_PATH             = 'simple_switch'
OBS_THRIFT_PORT     = 9090
TREE_SW_THRIFT_BASE = 9100

PROXY_SCRIPT    = 'proxy_multicast_tree_root_leaf.py'
RECEIVER_SCRIPT = 'receiver_multicast_tree_pro_max.py'
SENDER_SCRIPT   = 'sender_multicast_tree_root_leaf.py'

CSV_DIR   = '/tmp/multicast_exp'   # overridden in main()
BCAST_MAC = 'ff:ff:ff:ff:ff:ff'
BCAST_IP  = '10.255.255.255'


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _local_iface(node_name, iface_name):
    prefix = f'{node_name}-'
    if iface_name.startswith(prefix):
        return iface_name[len(prefix):]
    return iface_name


# ---------------------------------------------------------------------------
# Topology
# ---------------------------------------------------------------------------

class HybridTreeTopo(Topo):

    def __init__(self, h, d, k, multicast_json, obs_json,
                 placement='root', **opts):
        super().__init__(**opts)
        self.h              = h
        self.d              = d
        self.k              = k
        self.placement      = placement
        self.multicast_json = multicast_json
        self.obs_json       = obs_json

        self.root_switch   = None
        self.hw_switches   = []
        self.proxies       = []
        self.receivers     = []
        self.all_hosts     = []
        self.node_info     = {}

        self.child_iface_map = {}
        self.obs_iface_map   = {}
        self._iface_counter  = defaultdict(int)

        self._build()

    # -----------------------------------------------------------------------
    # Phase 1: compute node type map
    # -----------------------------------------------------------------------

    def _compute_node_types(self):
        node_type = {}
        h, d = self.h, self.d

        # All level-h nodes are receivers
        for pos in range(d ** h):
            node_type[(h, pos)] = 'receiver'

        total_internal = sum(d ** lvl for lvl in range(0, h))
        remaining = min(self.k, total_internal)

        # Default all internal nodes to host (proxy)
        for level in range(0, h):
            width = 1 if level == 0 else d ** level
            for pos in range(width):
                node_type[(level, pos)] = 'host'

        if self.placement == 'root':
            # Fill switches top-down: level 0 first, then 1, then 2 ...
            for level in range(0, h):
                width = 1 if level == 0 else d ** level
                for pos in range(width):
                    if remaining > 0:
                        node_type[(level, pos)] = 'switch'
                        remaining -= 1

        elif self.placement == 'leaf':
            # Fill switches bottom-up: level h-1 first, then h-2 ...
            for level in range(h - 1, -1, -1):
                width = 1 if level == 0 else d ** level
                for pos in range(width):
                    if remaining > 0:
                        node_type[(level, pos)] = 'switch'
                        remaining -= 1

        elif self.placement == 'subtree_cover':
            # Greedy top-down: cover the largest complete subtrees first.
            # A subtree rooted at level l costs (d^(h-l)-1)/(d-1) switches
            # and covers d^(h-l) receivers with fully-hardware delivery.
            # Remaining budget after each level falls through to smaller
            # subtrees at deeper levels.
            for level in range(0, h):
                width        = 1 if level == 0 else d ** level
                depth        = h - level   # internal levels in this subtree
                subtree_cost = (d**depth - 1) // (d - 1)

                if subtree_cost > remaining:
                    continue   # can't afford any subtree here; try smaller

                for pos in range(width):
                    if subtree_cost > remaining:
                        break   # exhausted budget for this level
                    if node_type[(level, pos)] == 'switch':
                        continue   # already covered by an ancestor subtree

                    # Mark every internal node of this complete subtree
                    for i in range(depth):
                        sub_level = level + i
                        n_at_sub  = d ** i
                        sub_start = pos * n_at_sub
                        for sub_pos in range(sub_start, sub_start + n_at_sub):
                            node_type[(sub_level, sub_pos)] = 'switch'

                    remaining -= subtree_cost

                if remaining == 0:
                    break

        elif self.placement == 'uniform':
            # Distribute switches proportionally across levels,
            # placed at evenly-spaced positions within each level.
            levels      = list(range(0, h))
            total_width = sum(1 if l == 0 else d**l for l in levels)
            if total_width > 0 and remaining > 0:
                fraction = remaining / total_width
                for level in levels:
                    width  = 1 if level == 0 else d**level
                    budget = min(int(round(fraction * width)), width)
                    if budget > 0:
                        step      = width / budget
                        positions = [int(i * step) for i in range(budget)]
                        for pos in positions:
                            node_type[(level, pos)] = 'switch'
                            remaining -= 1
                            if remaining == 0:
                                break
                if remaining > 0:
                    node_type[(0, 0)] = 'switch'

        return node_type

    # -----------------------------------------------------------------------
    # Helper: add a link and track iface counters / OBS iface
    # -----------------------------------------------------------------------

    def _add_link_tracked(self, a, b, direct_key=None):
        iface_a = f'{a}-eth{self._iface_counter[a]}'
        self._iface_counter[a] += 1
        self._iface_counter[b] += 1
        self.addLink(a, b)
        if direct_key is not None:
            self.child_iface_map[direct_key] = iface_a
        if b == 'obs':
            self.obs_iface_map[a] = iface_a
        return iface_a

    # -----------------------------------------------------------------------
    # Phase 2: build nodes and links
    # -----------------------------------------------------------------------

    def _build(self):
        h, d = self.h, self.d

        # OBS switch
        self.addSwitch(
            'obs',
            sw_path     = SW_PATH,
            json_path   = self.obs_json,
            thrift_port = OBS_THRIFT_PORT,
            pcap_dump   = False,
            dpid        = '0000000000000001',
        )

        # h0 — sender
        self.addHost('h0', ip='10.0.0.1/8', mac='00:00:00:00:00:01')
        self.all_hosts.append('h0')
        self.node_info['h0'] = {
            'ip': '10.0.0.1', 'mac': '00:00:00:00:00:01',
            'level': -1, 'pos': 0,
        }

        node_type     = self._compute_node_types()
        node_idx      = 2
        switch_cnt    = 0
        obs_connected = set()

        use_root_switch = (node_type.get((0, 0)) == 'switch')

        if use_root_switch:
            switch_cnt += 1
            tp = TREE_SW_THRIFT_BASE + switch_cnt
            self.addSwitch(
                'sw_l0_p0',
                sw_path     = SW_PATH,
                json_path   = self.multicast_json,
                thrift_port = tp,
                pcap_dump   = False,
                dpid        = f'{tp:016x}',
            )
            self.hw_switches.append('sw_l0_p0')
            self.root_switch = 'sw_l0_p0'
            self.node_info['sw_l0_p0'] = {
                'ip': None, 'mac': None, 'level': 0, 'pos': 0,
                'thrift_port': tp, 'child_ports': [],
            }
            levels       = [['h0'], ['sw_l0_p0']]
            level_offset = 1
        else:
            levels       = [['h0']]
            level_offset = 0

        # Build levels 1 .. h
        for level in range(1, h + 1):
            level_nodes = []
            for pos in range(d ** level):
                ntype = node_type[(level, pos)]

                if ntype == 'switch':
                    switch_cnt += 1
                    name = f'sw_l{level}_p{pos}'
                    tp   = TREE_SW_THRIFT_BASE + switch_cnt
                    self.addSwitch(
                        name,
                        sw_path     = SW_PATH,
                        json_path   = self.multicast_json,
                        thrift_port = tp,
                        pcap_dump   = False,
                        dpid        = f'{tp:016x}',
                    )
                    self.hw_switches.append(name)
                    self.node_info[name] = {
                        'ip': None, 'mac': None,
                        'level': level, 'pos': pos,
                        'thrift_port': tp, 'child_ports': [],
                    }
                else:
                    prefix = 'rc' if ntype == 'receiver' else 'hp'
                    name   = f'{prefix}_l{level}_p{pos}'
                    b2 = (node_idx >> 16) & 0xFF
                    b3 = (node_idx >>  8) & 0xFF
                    b4 =  node_idx        & 0xFF
                    ip  = f'10.{b2}.{b3}.{b4}'
                    mac = f'00:00:{b2:02x}:{b3:02x}:{b4:02x}:00'
                    self.addHost(name, ip=f'{ip}/8', mac=mac)
                    self.all_hosts.append(name)
                    self.node_info[name] = {
                        'ip': ip, 'mac': mac, 'level': level, 'pos': pos,
                    }
                    if ntype == 'receiver':
                        self.receivers.append(name)
                    else:
                        self.proxies.append(name)
                    node_idx += 1

                level_nodes.append(name)
            levels.append(level_nodes)

        # -------------------------------------------------------------------
        # Link creation
        # -------------------------------------------------------------------

        if self.placement == 'root' and self.k > 0:
            # h0 → sw_l0_p0 directly; mark h0 as handled (no OBS link)
            self._add_link_tracked('h0', 'sw_l0_p0',
                                   direct_key=('h0', 'sw_l0_p0'))
            obs_connected.add('h0')
            for level in range(1, h + 1):
                curr_idx   = level + level_offset
                parent_idx = level + level_offset - 1
                for pos in range(d ** level):
                    self._connect_parent_child(
                        levels[parent_idx][pos // d],
                        levels[curr_idx][pos],
                        node_type, level, pos,
                        obs_connected, levels, level_offset,
                    )

        elif self.placement == 'root' and self.k == 0:
            # Pure software: h0 → OBS, sends unicasts to level-1 proxies
            self._add_link_tracked('h0', 'obs')
            obs_connected.add('h0')
            for level in range(1, h + 1):
                curr_idx   = level + level_offset
                parent_idx = level + level_offset - 1
                for pos in range(d ** level):
                    self._connect_parent_child(
                        levels[parent_idx][pos // d],
                        levels[curr_idx][pos],
                        node_type, level, pos,
                        obs_connected, levels, level_offset,
                    )

        # elif self.placement in ('leaf', 'subtree_cover', 'uniform'):
        #     if len(levels) < 2:
        #         print("Warning: no level-1 nodes — skipping linking")
        #     else:
        #         # Level-1 children of h0
        #         for pos in range(min(d, len(levels[1]))):
        #             child = levels[1][pos]
        #             ntype = node_type.get((1, pos), 'host')
        #             if ntype == 'switch':
        #                 self._add_link_tracked('h0', child,
        #                                        direct_key=('h0', child))
        #             else:
        #                 if 'h0' not in obs_connected:
        #                     self._add_link_tracked('h0', 'obs')
        #                     obs_connected.add('h0')
        #                 if child not in obs_connected:
        #                     self._add_link_tracked(child, 'obs')
        #                     obs_connected.add(child)

        #         # Levels 2 .. h
        #         for level in range(2, h + 1):
        #             curr_idx   = level + level_offset
        #             parent_idx = level + level_offset - 1
        #             if curr_idx >= len(levels) or parent_idx >= len(levels):
        #                 continue
        #             for pos in range(d ** level):
        #                 self._connect_parent_child(
        #                     levels[parent_idx][pos // d],
        #                     levels[curr_idx][pos],
        #                     node_type, level, pos,
        #                     obs_connected, levels, level_offset,
        #                 )

        elif self.placement in ('leaf', 'subtree_cover', 'uniform'):
            if use_root_switch:
                # Root switch present: use same logic as root placement
                # so sw_l0_p0 gets connected to ALL its level-1 children
                self._add_link_tracked('h0', 'sw_l0_p0',
                                    direct_key=('h0', 'sw_l0_p0'))
                obs_connected.add('h0')
                for level in range(1, h + 1):          # <-- starts at 1, not 2
                    curr_idx   = level + level_offset
                    parent_idx = level + level_offset - 1
                    for pos in range(d ** level):
                        self._connect_parent_child(
                            levels[parent_idx][pos // d],
                            levels[curr_idx][pos],
                            node_type, level, pos,
                            obs_connected, levels, level_offset,
                        )
            else:
                # No root switch: existing logic is correct
                if len(levels) < 2:
                    print("Warning: no level-1 nodes — skipping linking")
                else:
                    for pos in range(min(d, len(levels[1]))):
                        child = levels[1][pos]
                        ntype = node_type.get((1, pos), 'host')
                        if ntype == 'switch':
                            self._add_link_tracked('h0', child,
                                                direct_key=('h0', child))
                        else:
                            if 'h0' not in obs_connected:
                                self._add_link_tracked('h0', 'obs')
                                obs_connected.add('h0')
                            if child not in obs_connected:
                                self._add_link_tracked(child, 'obs')
                                obs_connected.add(child)

                    for level in range(2, h + 1):
                        curr_idx   = level + level_offset
                        parent_idx = level + level_offset - 1
                        if curr_idx >= len(levels) or parent_idx >= len(levels):
                            continue
                        for pos in range(d ** level):
                            self._connect_parent_child(
                                levels[parent_idx][pos // d],
                                levels[curr_idx][pos],
                                node_type, level, pos,
                                obs_connected, levels, level_offset,
                            )

        # Default recv_iface for all receivers
        for name in self.receivers:
            self.node_info[name]['recv_iface'] = 'eth0'

    def _connect_parent_child(self, parent, child, node_type,
                               level, pos, obs_connected, levels, level_offset):
        child_ntype = node_type.get((level, pos), 'receiver')

        if parent in self.hw_switches:
            port_num = self._iface_counter[parent]
            self._add_link_tracked(parent, child, direct_key=(parent, child))
            self.node_info[parent]['child_ports'].append(port_num + 1)
            if child_ntype == 'receiver':
                self.node_info[child]['recv_iface'] = 'eth0'
        else:
            if child in self.hw_switches:
                self._add_link_tracked(parent, child,
                                       direct_key=(parent, child))
            else:
                if parent not in obs_connected:
                    self._add_link_tracked(parent, 'obs')
                    obs_connected.add(parent)
                if child not in obs_connected:
                    self._add_link_tracked(child, 'obs')
                    obs_connected.add(child)
                if child_ntype == 'receiver':
                    self.node_info[child]['recv_iface'] = 'eth0'


# ---------------------------------------------------------------------------
# Switch configuration
# ---------------------------------------------------------------------------

def _run_cli(thrift_port, commands, label=''):
    result = subprocess.run(
        ['simple_switch_CLI', '--thrift-port', str(thrift_port)],
        input=commands, capture_output=True, text=True,
    )
    ok = result.returncode == 0
    print(f'  [{label}] {"OK" if ok else "ERROR: " + result.stderr.strip()}')
    return ok


def configure_tree_switches(net, topo):
    print('\n--- Configuring tree switches (multicast) ---')
    d = topo.d
    for sw_name in topo.hw_switches:
        sw    = net.get(sw_name)
        info  = topo.node_info[sw_name]
        ports = info['child_ports'] if info['child_ports'] else list(range(2, d + 2))
        port_str = ' '.join(str(p) for p in ports)
        cmds = (
            f'mc_mgrp_create 1\n'
            f'mc_node_create 0 {port_str}\n'
            f'mc_node_associate 1 0'
        )
        print(f'  {sw_name}: multicast group 1 -> ports {port_str}')
        _run_cli(sw.thrift_port, cmds, sw_name)


def configure_obs(net, topo):
    print('\n--- Configuring OBS unicast forwarding table ---')
    obs  = net.get('obs')
    cmds = []
    for intf in obs.intfList():
        if intf.name == 'lo' or intf.link is None:
            continue
        other = intf.link.intf1 if intf.link.intf2 == intf else intf.link.intf2
        node  = other.node
        port  = obs.ports[intf]
        if isinstance(node, P4Host):
            ip = node.params.get('ip', '').split('/')[0]
            if ip:
                cmds.append(f'table_add ip_table forward {ip} => {port}')
        elif isinstance(node, P4Switch) and node.name != 'obs':
            ip = topo.node_info.get(node.name, {}).get('ip')
            if ip:
                cmds.append(f'table_add ip_table forward {ip} => {port}')
    cmds.sort()
    for c in cmds:
        print(f'  {c}')
    _run_cli(OBS_THRIFT_PORT, '\n'.join(cmds), 'obs')


# ---------------------------------------------------------------------------
# Host process management
# ---------------------------------------------------------------------------

def launch_receivers(net, topo):
    print('\n--- Launching receivers ---')
    os.makedirs(CSV_DIR, exist_ok=True)
    csv_paths = {}
    for idx, name in enumerate(topo.receivers):
        info     = topo.node_info[name]
        csv_path = os.path.join(CSV_DIR, f'{name}.csv')
        host     = net.get(name)
        iface    = info.get('recv_iface', 'eth0')
        cmd = (
            f'python3 {RECEIVER_SCRIPT} '
            f'--host-index {idx + 1} '
            f'--outfile {csv_path} '
            f'--iface {iface} '
            f'> /tmp/{name}_recv.log 2>&1 &'
        )
        host.cmd(cmd)
        csv_paths[name] = csv_path
        print(f'  {name} ({info["ip"]}) iface={iface} -> {csv_path}')
        time.sleep(0.05)
    return csv_paths


def _build_child_forward_list(node_name, topo):
    h, d  = topo.h, topo.d
    info  = topo.node_info[node_name]
    level = info['level']

    child_level = 1 if node_name == 'h0' else level + 1
    if child_level > h:
        return []

    child_count = d ** child_level
    my_pos      = info['pos'] if node_name != 'h0' else 0

    result = []
    for pos in range(child_count):
        if node_name != 'h0' and pos // d != my_pos:
            continue
        child_name = None
        for cname, cinfo in topo.node_info.items():
            if cinfo.get('level') == child_level and cinfo.get('pos') == pos:
                child_name = cname
                break
        if child_name is None:
            continue

        if child_name in topo.hw_switches:
            raw_iface = topo.child_iface_map.get((node_name, child_name))
            if raw_iface is None:
                continue
            iface = _local_iface(node_name, raw_iface)
            result.append((pos, BCAST_MAC, '', iface))
        else:
            cinfo     = topo.node_info[child_name]
            obs_raw   = topo.obs_iface_map.get(node_name, f'{node_name}-eth0')
            obs_iface = _local_iface(node_name, obs_raw)
            result.append((pos, cinfo['mac'], cinfo['ip'], obs_iface))

    result.sort(key=lambda x: x[0])
    return [(mac, ip, iface) for (_, mac, ip, iface) in result]


def launch_proxies(net, topo):
    print('\n--- Launching proxies ---')
    for name in topo.proxies:
        info     = topo.node_info[name]
        host     = net.get(name)
        fwd_list = _build_child_forward_list(name, topo)
        if not fwd_list:
            print(f'  {name}: no children — skipping')
            continue
        children_macs   = ','.join(mac   for mac, ip, iface in fwd_list)
        children_ips    = ','.join(ip    for mac, ip, iface in fwd_list)
        children_ifaces = ','.join(iface for mac, ip, iface in fwd_list)
        cmd = (
            f'python3 {PROXY_SCRIPT} '
            f'--my-mac {info["mac"]} '
            f'--my-ip {info["ip"]} '
            f'--children-macs {children_macs} '
            f'--children-ips {children_ips} '
            f'--children-ifaces {children_ifaces} '
            f'--iface-in eth0 '
            f'> /tmp/{name}_proxy.log 2>&1 &'
        )
        host.cmd(cmd)
        print(
            f'  {name} ({info["ip"]}) iface-in=eth0 '
            f'children-ifaces={children_ifaces} '
            f'children-ips={children_ips}'
        )
        time.sleep(0.05)


def verify_receivers(net, topo, csv_paths):
    print('  Verifying receiver processes ...')
    restarted = 0
    for idx, name in enumerate(topo.receivers):
        host = net.get(name)
        res  = host.cmd(f'pgrep -f "{RECEIVER_SCRIPT}" | wc -l').strip()
        if int(res) == 0:
            info     = topo.node_info[name]
            iface    = info.get('recv_iface', 'eth0')
            csv_path = csv_paths[name]
            cmd = (
                f'python3 {RECEIVER_SCRIPT} '
                f'--host-index {idx + 1} '
                f'--outfile {csv_path} '
                f'--iface {iface} '
                f'> /tmp/{name}_recv.log 2>&1 &'
            )
            host.cmd(cmd)
            print(f'    WARNING: restarted receiver on {name}')
            restarted += 1
    if restarted == 0:
        print('  All receiver processes running.')
    else:
        print(f'  Restarted {restarted} receiver(s) — waiting 2s ...')
        time.sleep(2)


def launch_sender(net, topo, cycles, gap_ms):
    print('\n--- Launching sender on h0 ---')
    h0 = net.get('h0')
    if topo.root_switch:
        raw_iface = topo.child_iface_map.get(('h0', 'sw_l0_p0'), 'h0-eth0')
        iface     = _local_iface('h0', raw_iface)
        cmd = (
            f'python3 {SENDER_SCRIPT} '
            f'--cycles {cycles} --gap {gap_ms} '
            f'--children-macs {BCAST_MAC} '
            f'--children-ips "" '
            f'--children-ifaces {iface}'
        )
    else:
        fwd_list = _build_child_forward_list('h0', topo)
        if not fwd_list:
            print('  h0: no children — cannot send')
            return
        children_macs   = ','.join(mac   for mac, ip, iface in fwd_list)
        children_ips    = ','.join(ip    for mac, ip, iface in fwd_list)
        children_ifaces = ','.join(iface for mac, ip, iface in fwd_list)
        cmd = (
            f'python3 {SENDER_SCRIPT} '
            f'--cycles {cycles} --gap {gap_ms} '
            f'--children-macs {children_macs} '
            f'--children-ips {children_ips} '
            f'--children-ifaces {children_ifaces}'
        )
    print(f'  h0: {cmd}')
    print(h0.cmd(cmd))


def kill_background_processes(net, topo):
    print('\n--- Stopping processes ---')
    for name in topo.receivers:
        net.get(name).cmd(
            'kill -TERM $(pgrep -f "receiver_multicast_tree_pro_max.py") 2>/dev/null'
        )
    for name in topo.proxies:
        net.get(name).cmd(
            'kill -9 $(pgrep -f "proxy_multicast_tree_root_leaf.py") 2>/dev/null'
        )


def wait_for_csvs(csv_paths, timeout=30):
    print(f'\n--- Waiting for CSV files (up to {timeout}s) ---')
    deadline = time.time() + timeout
    while time.time() < deadline:
        if all(os.path.exists(p) for p in csv_paths.values()):
            print('  All CSVs present.')
            return True
        time.sleep(0.2)
    missing = [n for n, p in csv_paths.items() if not os.path.exists(p)]
    print(f'  WARNING: CSVs still missing: {missing}')
    return False


# ---------------------------------------------------------------------------
# Results collection — DWS and OML
# ---------------------------------------------------------------------------

def _print_and_log(lines, log_fh):
    for line in lines:
        print(line)
        if log_fh:
            log_fh.write(line + '\n')


def _stat_block(values):
    n  = len(values)
    mn = sum(values) / n
    sd = (sum((x - mn) ** 2 for x in values) / n) ** 0.5
    sv = sorted(values)
    return [
        f'    mean : {mn:>10.1f} us  ({mn/1000:.3f} ms)',
        f'    std  : {sd:>10.1f} us',
        f'    p50  : {sv[n // 2]:>10} us',
        f'    p90  : {sv[int(n * 0.90)]:>10} us',
        f'    p95  : {sv[int(n * 0.95)]:>10} us',
        f'    p99  : {sv[int(n * 0.99)]:>10} us',
        f'    min  : {min(values):>10} us',
        f'    max  : {max(values):>10} us',
    ]


def collect_results(csv_paths, cycles, topo):
    log_path = os.path.join(CSV_DIR, 'summary.txt')
    try:
        log_fh = open(log_path, 'w')
    except Exception:
        log_fh = None

    def out(lines):
        _print_and_log(lines if isinstance(lines, list) else [lines], log_fh)

    sep = '=' * 60
    out(f'\n{sep}')
    out('RESULTS')
    out(sep)
    out(f'  h={topo.h}  d={topo.d}  k={topo.k}  placement={topo.placement}')
    out(f'  Root switch : {topo.root_switch}')
    out(f'  HW switches : {topo.hw_switches}')
    out(f'  Proxies     : {topo.proxies}')
    out('')

    n_receivers = len(csv_paths)
    msg_ts      = defaultdict(list)
    msg_e2e     = defaultdict(list)
    counts      = {}

    for name, csv_path in sorted(csv_paths.items()):
        if not os.path.exists(csv_path):
            out(f'  {name}: CSV not found')
            counts[name] = 0
            continue
        rows = []
        try:
            with open(csv_path, newline='') as f:
                for row in csv.DictReader(f):
                    rows.append(row)
        except Exception as e:
            out(f'  {name}: error reading CSV — {e}')
            counts[name] = 0
            continue

        counts[name] = len(rows)
        status = '✓' if len(rows) == cycles else f'✗ (got {len(rows)}, expected {cycles})'
        out(f'  {name}: {len(rows)}/{cycles} packets  {status}')

        for row in rows:
            try:
                mid = int(row['msg_id'])
                msg_ts[mid].append(int(row['recv_ts_us']))
                msg_e2e[mid].append(int(row['e2e_us']))
            except (KeyError, ValueError):
                continue

    complete_ids = {mid for mid, ts in msg_ts.items() if len(ts) >= n_receivers}
    partial_ids  = [mid for mid, ts in msg_ts.items() if 0 < len(ts) < n_receivers]

    out(f'\n  Messages fully received by all {n_receivers} receivers : '
        f'{len(complete_ids)}/{cycles}')
    if partial_ids:
        out(f'  Partially received msg_ids : {sorted(partial_ids)}')

    if not complete_ids:
        out('\n  No complete messages — cannot compute metrics.')
    else:
        dws = [max(msg_ts[mid]) - min(msg_ts[mid]) for mid in complete_ids]
        oml = [max(msg_e2e[mid])                   for mid in complete_ids]

        out('\n  Per-message DWS (max - min recv timestamp across receivers):')
        out(_stat_block(dws))
        out('\n  Per-message OML (max e2e latency across receivers):')
        out(_stat_block(oml))

    all_ok = all(c == cycles for c in counts.values())
    out('')
    if all_ok:
        out('  ✓ All receivers received all expected packets.')
    else:
        missing = [n for n, c in counts.items() if c != cycles]
        out(f'  ✗ Missing packets at: {missing}')
    out(sep)

    if log_fh:
        log_fh.close()
        print(f'\n  Summary saved to: {log_path}')


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    global CSV_DIR

    parser = argparse.ArgumentParser(
        description='Hybrid multicast tree — root / leaf / subtree_cover / uniform'
    )
    parser.add_argument('--h',               type=int,   required=True)
    parser.add_argument('--d',               type=int,   required=True)
    parser.add_argument('--k',               type=int,   required=True)
    parser.add_argument('--cycles',          type=int,   default=100)
    parser.add_argument('--gap',             type=float, default=1.0,
                        help='Gap between cycles in ms (use >=100 for k=0)')
    parser.add_argument('--multicast-json',  default='multicast_int.json')
    parser.add_argument('--obs-json',        default='ip_fwd.json')
    parser.add_argument('--placement',       default='root',
                        choices=['root', 'leaf', 'subtree_cover', 'uniform'])
    parser.add_argument('--no-cli',          action='store_true')
    parser.add_argument('--post-proxy-wait', type=int, default=5)
    parser.add_argument('--post-send-wait',  type=int, default=5)
    args = parser.parse_args()

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    CSV_DIR   = os.path.join(
        os.getcwd(),
        f'results_h{args.h}_d{args.d}_k{args.k}_{args.placement}_{timestamp}'
    )
    os.makedirs(CSV_DIR, exist_ok=True)
    print(f'\n*** Results will be saved to: {CSV_DIR} ***\n')

    setLogLevel('info')
    subprocess.run(['mn', '--clean'], capture_output=True)
    time.sleep(1)

    print('\n--- Building topology ---')
    topo = HybridTreeTopo(
        args.h, args.d, args.k,
        args.multicast_json, args.obs_json,
        placement=args.placement,
    )
    net = Mininet(topo=topo, host=P4Host, switch=P4Switch, controller=None)
    net.start()

    for host in net.hosts:
        host.cmd('sysctl -w net.ipv6.conf.all.disable_ipv6=1 2>/dev/null')
        for intf in host.intfList():
            if intf.name != 'lo' and '-' in intf.name:
                host.cmd(f'ip link set {intf.name} name {intf.name.split("-", 1)[1]}')
        host.setDefaultRoute('dev eth0')

    print('\nWaiting 3s for switches to initialise ...')
    time.sleep(3)

    configure_tree_switches(net, topo)
    configure_obs(net, topo)

    print('\n--- Topology summary ---')
    print(f'  h={args.h}  d={args.d}  k={args.k}  placement={args.placement}')
    print(f'  Root switch : {topo.root_switch}')
    print(f'  HW switches : {topo.hw_switches}')
    print(f'  Proxies     : {topo.proxies}')
    print(f'  Receivers   : {topo.receivers}')

    csv_paths = launch_receivers(net, topo)
    launch_proxies(net, topo)

    print(f'\nWaiting {args.post_proxy_wait}s for receivers/proxies to initialise ...')
    time.sleep(args.post_proxy_wait)

    verify_receivers(net, topo, csv_paths)

    launch_sender(net, topo, args.cycles, args.gap)

    print(f'\nWaiting {args.post_send_wait}s for packets to drain ...')
    time.sleep(args.post_send_wait)

    kill_background_processes(net, topo)
    wait_for_csvs(csv_paths)
    collect_results(csv_paths, args.cycles, topo)

    if not args.no_cli:
        print('\nDropping into Mininet CLI. Type "exit" to stop.\n')
        CLI(net)
    net.stop()


if __name__ == '__main__':
    main()
