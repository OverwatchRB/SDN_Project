#!/usr/bin/env python3
"""
Usage:
    sudo python3 baseline_host.py --d 4 --cycles 1000 --gap 50 --no-cli
"""

# Import standard libraries 
import argparse
import csv
import os
import subprocess
import time
from collections import defaultdict
from datetime import datetime

from mininet.topo import Topo
from mininet.net import Mininet
from mininet.log import setLogLevel
from mininet.cli import CLI
from p4_mininet import P4Host

# Constants

BCAST_MAC       = 'ff:ff:ff:ff:ff:ff'
SENDER_SCRIPT   = 'sender_multicast_tree_root_leaf.py'
PROXY_SCRIPT    = 'proxy_multicast_tree_root_leaf.py'
RECEIVER_SCRIPT = 'receiver_multicast_tree_pro_max.py'
SUMMARY_CSV     = 'baseline_host_summary.csv'
SUMMARY_HEADER  = [
    'd', 'n_complete', 'cycles',
    'dws_mean_us', 'dws_std_us', 'dws_median_us', 'dws_p90_us', 'dws_p99_us',
    'oml_mean_us', 'oml_std_us', 'oml_median_us', 'oml_p90_us', 'oml_p99_us',
    'gap_ms', 'timestamp',
]


# This class defines the Mininet topology for the baseline host-proxy experiment. 
# The topology consists of a single sender host (h0) connected to a proxy host, 
# which in turn is connected to d receiver hosts (rc_0, rc_1, ..., rc_{d-1}). 
# The sender sends packets to the proxy, which replicates them to the receivers. 
# Each host and interface is assigned specific IP and MAC addresses for clarity and consistency 
# in the experiment.
class BaselineHostTopo(Topo):
    # Initializes the topology with the specified number of receivers (d) and builds the network.
    def __init__(self, d, **opts):
        self.d = d
        super().__init__(**opts)

    # Builds the topology by adding hosts and links according to the defined structure.
    def build(self):
        d     = self.d
        h0    = self.addHost('h0',    ip='10.0.0.1/8', mac='00:00:00:00:00:01')
        proxy = self.addHost('proxy', ip='10.0.0.2/8', mac='00:00:00:00:00:02')
        self.addLink(h0, proxy)
        for i in range(d):
            rc = self.addHost(
                f'rc_{i}',
                ip  = f'10.2.0.{i + 1}/8',
                mac = f'00:02:00:00:00:{i + 1:02x}',
            )
            self.addLink(proxy, rc)


# This function fixes the interface names on all hosts in the Mininet topology.
def fix_iface_names(net):
    for host in net.hosts:
        host.cmd('sysctl -w net.ipv6.conf.all.disable_ipv6=1 2>/dev/null')
        for intf in host.intfList():
            name = intf.name
            if name == 'lo' or '-' not in name:
                continue
            host.cmd(f'ip link set {name} name {name.split("-", 1)[1]}')
    time.sleep(0.5)

# This function computes the p-th percentile of a sorted list of values.
def percentile(sv, p):
    return sv[min(int(len(sv) * p), len(sv) - 1)]

# This function computes and prints the results of the experiment based on the collected CSV data 
# from the receivers.
def compute_and_print_results(csv_paths, cycles, d, gap_ms, csv_dir):
    msg_ts  = defaultdict(list)
    msg_e2e = defaultdict(list)

    for name, path in sorted(csv_paths.items()):
        if not os.path.exists(path):
            print(f'  WARNING: {path} missing')
            continue
        rows = 0
        try:
            with open(path, newline='') as f:
                for row in csv.DictReader(f):
                    mid = int(row['msg_id'])
                    msg_ts[mid].append(int(row['recv_ts_us']))
                    msg_e2e[mid].append(int(row['e2e_us']))
                    rows += 1
        except Exception as e:
            print(f'  ERROR reading {path}: {e}')
            continue
        print(f'  {name}: {"OK" if rows == cycles else f"NOT OK got {rows}/{cycles}"}')

    complete = [mid for mid, ts in msg_ts.items() if len(ts) >= d]

    sep = '=' * 55
    print(f'\n{sep}')
    print(f'RESULTS  baseline_host  d={d}  gap={gap_ms}ms')
    print(sep)
    print(f'  Complete messages: {len(complete)}/{cycles}')

    if not complete:
        print('  No complete messages — check logs.')
        print(sep)
        return

    dws = sorted([max(msg_ts[m])  - min(msg_ts[m]) for m in complete])
    oml = sorted([max(msg_e2e[m])                   for m in complete])
    n   = len(dws)
    
    # This inner function computes and prints the statistics for a given label and list of values.
    def show(label, vals):
        mn = sum(vals) / n
        sd = (sum((x - mn) ** 2 for x in vals) / n) ** 0.5
        print(f'\n  {label}:')
        print(f'    mean   : {mn:>8.1f} us  ({mn/1000:.3f} ms)')
        print(f'    std    : {sd:>8.1f} us')
        print(f'    median : {percentile(vals, 0.50):>8} us')
        print(f'    p90    : {percentile(vals, 0.90):>8} us')
        print(f'    p99    : {percentile(vals, 0.99):>8} us')
        print(f'    min    : {vals[0]:>8} us')
        print(f'    max    : {vals[-1]:>8} us')

    show('DWS (max − min recv_ts across receivers)', dws)
    show('OML (max e2e latency across receivers)',   oml)
    print(f'\n{sep}')

    # Save per-run summary
    summary_path = os.path.join(csv_dir, 'summary.txt')
    with open(summary_path, 'w') as f:
        def s(label, vals):
            mn = sum(vals) / n
            sd = (sum((x - mn) ** 2 for x in vals) / n) ** 0.5
            f.write(f'  {label}:\n')
            f.write(f'    mean   : {mn:>10.1f} us  ({mn/1000:.3f} ms)\n')
            f.write(f'    std    : {sd:>10.1f} us\n')
            f.write(f'    median : {percentile(vals, 0.50):>10} us\n')
            f.write(f'    p90    : {percentile(vals, 0.90):>10} us\n')
            f.write(f'    p99    : {percentile(vals, 0.99):>10} us\n')
            f.write(f'    min    : {vals[0]:>10} us\n')
            f.write(f'    max    : {vals[-1]:>10} us\n')
        f.write(f'd={d}  gap={gap_ms}ms  cycles={cycles}\n\n')
        f.write(f'Complete messages: {len(complete)}/{cycles}\n\n')
        f.write('DWS:\n'); s('DWS', dws)
        f.write('\nOML:\n'); s('OML', oml)
    print(f'  Summary saved -> {summary_path}')

    # Append to global summary CSV
    dws_mean = sum(dws) / n
    dws_std  = (sum((x - dws_mean) ** 2 for x in dws) / n) ** 0.5
    oml_mean = sum(oml) / n
    oml_std  = (sum((x - oml_mean) ** 2 for x in oml) / n) ** 0.5
    write_header = not os.path.exists(SUMMARY_CSV)
    with open(SUMMARY_CSV, 'a', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=SUMMARY_HEADER)
        if write_header:
            writer.writeheader()
        writer.writerow({
            'd'            : d,
            'n_complete'   : n,
            'cycles'       : cycles,
            'dws_mean_us'  : round(dws_mean, 2),
            'dws_std_us'   : round(dws_std,  2),
            'dws_median_us': percentile(dws, 0.50),
            'dws_p90_us'   : percentile(dws, 0.90),
            'dws_p99_us'   : percentile(dws, 0.99),
            'oml_mean_us'  : round(oml_mean, 2),
            'oml_std_us'   : round(oml_std,  2),
            'oml_median_us': percentile(oml, 0.50),
            'oml_p90_us'   : percentile(oml, 0.90),
            'oml_p99_us'   : percentile(oml, 0.99),
            'gap_ms'       : gap_ms,
            'timestamp'    : datetime.now().strftime('%Y%m%d_%H%M%S'),
        })
    print(f'  Summary appended -> {SUMMARY_CSV}')


# This function launches the receiver processes on each of the receiver hosts 
# in the Mininet topology.
def launch_receivers(net, d, csv_dir):
    csv_paths = {}
    for i in range(d):
        rc       = net.get(f'rc_{i}')
        csv_path = os.path.join(csv_dir, f'rc_{i}.csv')
        csv_paths[f'rc_{i}'] = csv_path
        rc.cmd(
            f'python3 {RECEIVER_SCRIPT} '
            f'--host-index {i + 1} '
            f'--outfile {csv_path} '
            f'--iface eth0 '
            f'> /tmp/rc_{i}.log 2>&1 &'
        )
        print(f'  rc_{i}: eth0 -> {csv_path}')
    return csv_paths

# This function launches the proxy process on the proxy host in the Mininet topology,
def launch_proxy(net, d):
    proxy           = net.get('proxy')
    children_macs   = ','.join(BCAST_MAC for _ in range(d))
    children_ips    = ','.join('' for _ in range(d))
    children_ifaces = ','.join(f'eth{i + 1}' for i in range(d))
    proxy.cmd(
        f'python3 {PROXY_SCRIPT} '
        f'--my-mac 00:00:00:00:00:02 '
        f'--my-ip 10.0.0.2 '
        f'--children-macs {children_macs} '
        f'--children-ips "{children_ips}" '
        f'--children-ifaces {children_ifaces} '
        f'--iface-in eth0 '
        f'> /tmp/proxy.log 2>&1 &'
    )
    print(f'  proxy: eth0 -> [{children_ifaces}]')

# This function launches the sender process on the sender host in the Mininet topology.
def launch_sender(net, cycles, gap_ms):
    h0  = net.get('h0')
    cmd = (
        f'python3 {SENDER_SCRIPT} '
        f'--cycles {cycles} '
        f'--gap {gap_ms} '
        f'--children-macs {BCAST_MAC} '
        f'--children-ips "" '
        f'--children-ifaces eth0'
    )
    print(f'\n  Sender: {cmd}')
    out = h0.cmd(cmd)
    for line in [l for l in out.strip().splitlines() if l.strip()][-3:]:
        print(f'  [h0] {line}')

# This function kills the sender, proxy, and receiver processes on all hosts in the Mininet topology.
def kill_processes(net, d):
    net.get('proxy').cmd(f'kill -9 $(pgrep -f "{PROXY_SCRIPT}") 2>/dev/null')
    for i in range(d):
        net.get(f'rc_{i}').cmd(
            f'kill -TERM $(pgrep -f "{RECEIVER_SCRIPT}") 2>/dev/null'
        )
    time.sleep(1)


# The main function parses command-line arguments, sets up the Mininet topology, 
# launches the sender, proxy, and receiver processes, collects results, and 
# optionally drops into the Mininet CLI for further interaction.
def main():
    parser = argparse.ArgumentParser(
        description='Baseline host-proxy replication: h0 -> proxy -> receivers'
    )
    parser.add_argument('--d',      type=int,   required=True,
                        help='Number of receivers (fanout)')
    parser.add_argument('--cycles', type=int,   default=1000,
                        help='Number of packets to send (default: 1000)')
    parser.add_argument('--gap',    type=float, default=50.0,
                        help='Inter-packet gap in ms (default: 50ms = 20pps)')
    parser.add_argument('--no-cli', action='store_true',
                        help='Skip Mininet CLI after experiment')
    args = parser.parse_args()

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_dir   = f'baseline_host_d{args.d}_c{args.cycles}_gap{args.gap}ms_{timestamp}'
    os.makedirs(csv_dir, exist_ok=True)

    print(f'\n{"="*55}')
    print(f'Baseline Host-Proxy Experiment')
    print(f'  d={args.d}  cycles={args.cycles}  gap={args.gap}ms  '
          f'({1000/args.gap:.0f} pps)')
    print(f'  csv_dir -> {csv_dir}')
    print(f'{"="*55}\n')

    subprocess.run(['mn', '--clean'], capture_output=True)
    time.sleep(1)
    setLogLevel('info')

    print('--- Building topology ---')
    topo = BaselineHostTopo(d=args.d)
    net  = Mininet(topo=topo, host=P4Host, switch=None, controller=None)
    net.start()

    print('\n--- Fixing interface names ---')
    fix_iface_names(net)

    print('\n--- Launching receivers ---')
    csv_paths = launch_receivers(net, args.d, csv_dir)

    print('\n--- Launching proxy ---')
    launch_proxy(net, args.d)

    print('\n--- Waiting 2s for processes to initialise ---')
    time.sleep(2)

    print('\n--- Sending packets ---')
    launch_sender(net, args.cycles, args.gap)

    print('\n--- Waiting 3s for packets to drain ---')
    time.sleep(3)

    print('\n--- Stopping processes ---')
    kill_processes(net, args.d)

    print('\n--- Collecting results ---')
    compute_and_print_results(csv_paths, args.cycles, args.d, args.gap, csv_dir)

    if not args.no_cli:
        print('\nDropping into Mininet CLI. Type "exit" to stop.\n')
        CLI(net)

    net.stop()


if __name__ == '__main__':
    main()
