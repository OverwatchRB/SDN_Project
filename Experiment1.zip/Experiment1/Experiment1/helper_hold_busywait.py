#!/usr/bin/env python3
"""
Usage:
    python3 sw_receiver_v3.py \
        --in-iface  eth0 \
        --out-iface eth1 \
        --target-latency 2.0    # milliseconds
"""

import argparse
import queue
import socket
import struct
import time
from threading import Thread

from scapy.all import Ether, sniff

ETYPE_INT      = 0x1234
SEND_TS_OFFSET = 66    # Ethernet(14) + INT(24) + IPv4(20) + UDP(8)

pkt_queue: queue.Queue = queue.Queue()

# This function extracts the send timestamp (in microseconds) from the packet bytes.
def extract_send_ts_us(pkt_bytes: bytes):
    """
    Extract send_ts (microseconds, uint64 big-endian) from packet.
    Returns None if packet is too short or send_ts is 0.
    """
    if len(pkt_bytes) < SEND_TS_OFFSET + 8:
        return None
    ts = struct.unpack_from('>Q', pkt_bytes, SEND_TS_OFFSET)[0]
    return ts if ts != 0 else None


# This function runs in the receiver thread. It sniffs for packets of type ETYPE_INT 
# on the specified input interface, extracts the send timestamp, computes the release time 
# based on the target latency, and enqueues the release time and raw packet bytes for the 
# releaser thread to process.
def receiver_thread(in_iface: str, target_latency_ns: int):
    """
    Sniffs ETYPE_INT packets on in_iface.
    Computes release_time_ns = send_ts_us * 1000 + target_latency_ns.
    Enqueues (release_time_ns, raw_bytes).
    """
    def handle(pkt):
        if Ether not in pkt:
            return
        if pkt[Ether].type != ETYPE_INT:
            return
        raw = bytes(pkt)
        send_ts_us = extract_send_ts_us(raw)
        if send_ts_us is None:
            return
        release_time_ns = send_ts_us * 1000 + target_latency_ns
        pkt_queue.put((release_time_ns, raw))

    sniff(
        iface   = in_iface,
        prn     = handle,
        store   = False,
        filter  = 'ether proto 0x1234',
        promisc = True,
    )


# This function runs in the releaser thread. It continuously dequeues the release time 
# and raw packet bytes, busy-waits until the release time is reached, and then forwards 
# the raw bytes on the specified output interface using an AF_PACKET socket.
def releaser_thread(out_iface: str):
    """
    Dequeues (release_time_ns, raw_bytes).
    Pure busy-wait until release_time_ns.
    Forwards raw bytes on out_iface via AF_PACKET socket.
    """
    sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
    sock.bind((out_iface, 0))

    while True:
        try:
            release_time_ns, raw = pkt_queue.get(timeout=1.0)
        except queue.Empty:
            continue

        # Pure busy-wait — no sleep, maximum precision
        while time.time_ns() < release_time_ns:
            pass

        # Forward via AF_PACKET — no scapy overhead
        sock.send(raw)


# The main function parses command-line arguments for the input and output interfaces
# and target latency, starts the receiver and releaser threads, and waits for the
# receiver thread to finish (which it never does in this implementation).   
def main():
    parser = argparse.ArgumentParser(
        description='HW switch port model: pure busy-wait hold-and-forward'
    )
    parser.add_argument('--in-iface',
                        required=True,
                        help='Interface to receive from')
    parser.add_argument('--out-iface',
                        required=True,
                        help='Interface to forward to')
    parser.add_argument('--target-latency',
                        required=True,
                        type=float,
                        help='Target latency in milliseconds')
    args = parser.parse_args()

    target_latency_ns = int(args.target_latency * 1e6)

    print(
        f'[helper-v3] in={args.in_iface} out={args.out_iface} '
        f'target={args.target_latency}ms ({target_latency_ns}ns) '
        f'[pure busy-wait]',
        flush=True,
    )

    r = Thread(
        target = receiver_thread,
        args   = (args.in_iface, target_latency_ns),
        daemon = True,
        name   = 'receiver',
    )
    s = Thread(
        target = releaser_thread,
        args   = (args.out_iface,),
        daemon = True,
        name   = 'releaser',
    )

    r.start()
    s.start()
    r.join()


if __name__ == '__main__':
    main()
