#!/usr/bin/env python3
"""
Usage:
    python3 plot_switch_comparison.py --base . --out switch_comparison.png
"""

import os
import re
import glob
import argparse
from collections import defaultdict

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

RE_SWITCH_ONLY = re.compile(
    r'hw_switch_only_d(?P<d>\d+)_c\d+_gap[\d\.]+ms_\d{8}_\d{6}'
)
RE_BUSYWAIT = re.compile(
    r'hw_busywait_d(?P<d>\d+)_tl[\d\.]+ms_c\d+_gap[\d\.]+ms_\d{8}_\d{6}'
)
RE_SLEEP = re.compile(
    r'hw_sleep_d(?P<d>\d+)_tl[\d\.]+ms_c\d+_gap[\d\.]+ms_\d{8}_\d{6}'
)

RE_DWS_MEAN = re.compile(r'DWS.*?mean\s*:\s*([\d\.]+)\s*us', re.DOTALL)
RE_OML_MEAN = re.compile(r'OML.*?mean\s*:\s*([\d\.]+)\s*us', re.DOTALL)
RE_DWS_P90  = re.compile(r'DWS.*?p90\s*:\s*([\d\.]+)\s*us',  re.DOTALL)
RE_OML_P90  = re.compile(r'OML.*?p90\s*:\s*([\d\.]+)\s*us',  re.DOTALL)


def parse_summary(path):
    try:
        with open(path) as f:
            text = f.read()
    except OSError:
        return None
    m_dm = RE_DWS_MEAN.search(text)
    m_om = RE_OML_MEAN.search(text)
    m_dp = RE_DWS_P90.search(text)
    m_op = RE_OML_P90.search(text)
    if not all([m_dm, m_om, m_dp, m_op]):
        return None
    return {
        'dws_mean': float(m_dm.group(1)),
        'oml_mean': float(m_om.group(1)),
        'dws_p90':  float(m_dp.group(1)),
        'oml_p90':  float(m_op.group(1)),
    }


def collect(base_dir, regex):
    groups = defaultdict(list)
    for dpath in glob.glob(os.path.join(base_dir, '*')):
        m = regex.match(os.path.basename(dpath))
        if not m:
            continue
        d     = int(m.group('d'))
        stats = parse_summary(os.path.join(dpath, 'summary.txt'))
        if stats is None:
            print(f'  [warn] no valid summary in {os.path.basename(dpath)}')
            continue
        groups[d].append((stats, os.path.basename(dpath)))

    result = {}
    for d, items in sorted(groups.items()):
        best, name = min(items, key=lambda x: x[0]['oml_mean'])
        result[d] = best
        print(f'  d={d}  DWS={best["dws_mean"]:.1f}us  OML={best["oml_mean"]:.1f}us  <- {name}')
    return result


def plot(all_data, out_path):
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    cases = [
        ('switch_only', '#d62728', 's', 'Switch only'),
        ('busywait',    '#1f77b4', 'o', 'Switch + helpers (busy-wait)'),
        ('sleep',       '#2ca02c', '^', 'Switch + helpers (sleep)'),
    ]

    for case_id, color, marker, label in cases:
        data = all_data.get(case_id, {})
        if not data:
            print(f'  [warn] no data for: {label}')
            continue
        ds       = sorted(data.keys())
        dws_mean = [data[d]['dws_mean'] / 1000 for d in ds]
        oml_mean = [data[d]['oml_mean'] / 1000 for d in ds]
        dws_p90  = [data[d]['dws_p90']  / 1000 for d in ds]
        oml_p90  = [data[d]['oml_p90']  / 1000 for d in ds]

        axes[0].plot(ds, dws_mean, marker=marker, color=color,
                     linewidth=2, markersize=6, label=f'{label} (mean)')
        axes[0].plot(ds, dws_p90, marker=marker, color=color,
                     linewidth=1.2, markersize=4, linestyle='--',
                     alpha=0.7, label=f'{label} (p90)')
        axes[1].plot(ds, oml_mean, marker=marker, color=color,
                     linewidth=2, markersize=6, label=f'{label} (mean)')
        axes[1].plot(ds, oml_p90, marker=marker, color=color,
                     linewidth=1.2, markersize=4, linestyle='--',
                     alpha=0.7, label=f'{label} (p90)')

    axes[0].set_title('Per-message DWS\n(max − min recv timestamp across receivers)', fontsize=10)
    axes[1].set_title('Per-message OML\n(max e2e latency across receivers)', fontsize=10)

    for ax in axes:
        ax.set_xlabel('Number of receivers (d)', fontsize=11)
        ax.set_ylabel('Duration (ms)', fontsize=10)
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
        ax.grid(True, linestyle='--', alpha=0.45)
        ax.legend(fontsize=8)

    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches='tight')
    print(f'\nPlot saved -> {out_path}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', default='.', help='Directory containing result folders')
    parser.add_argument('--out',  default='switch_comparison.png')
    args = parser.parse_args()

    all_data = {}

    print('\n[Switch only]')
    all_data['switch_only'] = collect(args.base, RE_SWITCH_ONLY)

    print('\n[Switch + busy-wait]')
    all_data['busywait'] = collect(args.base, RE_BUSYWAIT)

    print('\n[Switch + sleep]')
    all_data['sleep'] = collect(args.base, RE_SLEEP)

    if not any(all_data.values()):
        print('No data found. Exiting.')
        return

    plot(all_data, args.out)


if __name__ == '__main__':
    main()
