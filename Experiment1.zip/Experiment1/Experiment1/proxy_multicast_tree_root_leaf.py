#!/usr/bin/env python3

import argparse
import socket
import sys

from scapy.all import Ether, sniff


ETYPE_INT      = 0x1234
INT_HEADER_LEN = 24

ETH_DST_OFF    = 0
ETH_SRC_OFF    = 6
ETH_HDR_LEN    = 14

IPV4_SRC_OFF   = ETH_HDR_LEN + INT_HEADER_LEN + 12
IPV4_DST_OFF   = ETH_HDR_LEN + INT_HEADER_LEN + 16
IPV4_CKSUM_OFF = ETH_HDR_LEN + INT_HEADER_LEN + 10


def mac_to_bytes(mac: str) -> bytes:
    return bytes(int(x, 16) for x in mac.split(':'))


def is_my_packet(raw_frame: bytearray, my_ip_bytes: bytes) -> bool:
    if len(raw_frame) < IPV4_SRC_OFF + 4:
        return False
    return raw_frame[IPV4_SRC_OFF:IPV4_SRC_OFF + 4] == my_ip_bytes


# This function takes a raw Ethernet frame and modifies it to forward to the specified destination
# MAC and IP addresses.
def forward_frame(raw_frame: bytearray,
                  my_mac_bytes: bytes,
                  my_ip_bytes: bytes,
                  dst_mac: str,
                  dst_ip: str) -> bytearray:
    
    fwd = bytearray(raw_frame)
    fwd[ETH_DST_OFF:ETH_DST_OFF + 6] = mac_to_bytes(dst_mac)
    fwd[ETH_SRC_OFF:ETH_SRC_OFF + 6] = my_mac_bytes
    if dst_ip:
        fwd[IPV4_SRC_OFF:IPV4_SRC_OFF + 4] = my_ip_bytes
        fwd[IPV4_DST_OFF:IPV4_DST_OFF + 4] = socket.inet_aton(dst_ip)
        fwd[IPV4_CKSUM_OFF:IPV4_CKSUM_OFF + 2] = b'\x00\x00'
    return fwd

# The main function parses command-line arguments for the proxy relay, including the 
# proxy's own MAC and IP addresses, the MAC and IP addresses of the child nodes, 
# the input interface to sniff on, and options for debugging and packet count. It then sets up 
# raw sockets for each unique outgoing interface and starts sniffing for packets on the input 
# interface. For each packet that matches the criteria (Ethernet type ETYPE_INT and not sent 
# by the proxy itself), it forwards the packet to each child node according to the specified 
# forwarding rules (OBS or direct) and prints debug information if enabled. The program can be 
# stopped with a keyboard interrupt, at which point it will close the raw sockets and 
# print a summary of the number of packets forwarded.
def main():
    parser = argparse.ArgumentParser(
        description='Proxy relay — per-child iface forwarding (root/leaf)'
    )
    parser.add_argument('--my-mac',           required=True)
    parser.add_argument('--my-ip',            required=True)
    parser.add_argument('--children-macs',    required=True,
                        help='Comma-separated MAC per child')
    parser.add_argument('--children-ips',     required=True,
                        help='Comma-separated IP per child; empty string '
                             'for direct switch children')
    parser.add_argument('--children-ifaces',  required=True,
                        help='Comma-separated iface per child; eth0 for OBS '
                             'path, ethX for direct switch children')
    parser.add_argument('--iface-in',         required=True,
                        help='Interface to sniff/receive on')
    parser.add_argument('--debug',            action='store_true')
    parser.add_argument('--count',            type=int, default=0)
    args = parser.parse_args()

    children_macs   = args.children_macs.split(',')
    children_ips    = args.children_ips.split(',')
    children_ifaces = args.children_ifaces.split(',')

    if not (len(children_macs) == len(children_ips) == len(children_ifaces)):
        raise ValueError(
            '--children-macs, --children-ips, --children-ifaces '
            'must all have the same number of entries'
        )

    children = list(zip(children_macs, children_ips, children_ifaces))

    my_mac_bytes = mac_to_bytes(args.my_mac)
    my_ip_bytes  = socket.inet_aton(args.my_ip)

    # Open one raw socket per unique outgoing interface
    unique_ifaces = set(iface for _, _, iface in children)
    raw_socks = {}
    for iface in unique_ifaces:
        s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
        s.bind((iface, 0))
        raw_socks[iface] = s

    print(f'[proxy {args.my_mac}]',                    file=sys.stderr)
    print(f'  my IP          : {args.my_ip}',           file=sys.stderr)
    print(f'  iface-in       : {args.iface_in}',        file=sys.stderr)
    print(f'  children:',                               file=sys.stderr)
    for mac, ip, iface in children:
        mode = f'OBS -> {ip}' if ip else 'direct (broadcast)'
        print(f'    {mac}  iface={iface}  {mode}',      file=sys.stderr)

    pkt_count = 0

    def handler(pkt):
        nonlocal pkt_count

        if Ether not in pkt or pkt[Ether].type != ETYPE_INT:
            return

        raw = bytearray(bytes(pkt))

        if is_my_packet(raw, my_ip_bytes):
            return

        pkt_count += 1

        for dst_mac, dst_ip, iface in children:
            fwd = forward_frame(raw, my_mac_bytes, my_ip_bytes,
                                dst_mac, dst_ip)
            raw_socks[iface].send(bytes(fwd))

            if args.debug:
                mode = f'OBS ip={dst_ip}' if dst_ip else 'direct'
                print(f'  [#{pkt_count}] -> {dst_mac} iface={iface} ({mode})',
                      file=sys.stderr)

    print(f'  Sniffing on {args.iface_in} ...', file=sys.stderr)

    sniff_kwargs = dict(
        iface   = args.iface_in,
        prn     = handler,
        store   = False,
        promisc = True,
    )
    if args.count > 0:
        sniff_kwargs['count'] = args.count

    try:
        sniff(**sniff_kwargs)
    except KeyboardInterrupt:
        pass

    for s in raw_socks.values():
        s.close()
    print(f'[proxy {args.my_mac}] Done. Forwarded {pkt_count} packets.',
          file=sys.stderr)


if __name__ == '__main__':
    main()
