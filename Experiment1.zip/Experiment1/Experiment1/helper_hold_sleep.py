#!/usr/bin/env python3
"""
Usage:
    python3 sw_receiver_v2.py \
        --in-iface  eth0 \
        --out-iface eth1 \
        --target-latency 2.0    # milliseconds
"""

import argparse
import queue
import socket
import struct
import time
from threading import Thread

from scapy.all import Ether, sniff


ETYPE_INT      = 0x1234
SEND_TS_OFFSET = 66
SPIN_EARLY_NS  = 1_000_000

pkt_queue: queue.Queue = queue.Queue()



def extract_send_ts_us(pkt_bytes: bytes):
    # Extracts the send timestamp from the packet bytes, returns None if not found.
    if len(pkt_bytes) < SEND_TS_OFFSET + 8:
        return None
    ts = struct.unpack_from('>Q', pkt_bytes, SEND_TS_OFFSET)[0]
    return ts if ts != 0 else None



def receiver_thread(in_iface: str, target_latency_ns: int):
    # Thread to sniff packets and enqueue them with their release time.
    def handle(pkt):
        if Ether not in pkt:
            return
        if pkt[Ether].type != ETYPE_INT:
            return
        raw = bytes(pkt)
        send_ts_us = extract_send_ts_us(raw)
        if send_ts_us is None:
            return
        release_time_ns = send_ts_us * 1000 + target_latency_ns
        pkt_queue.put((release_time_ns, raw))

    sniff(
        iface   = in_iface,
        prn     = handle,
        store   = False,
        filter  = 'ether proto 0x1234',
        promisc = True,
    )



def releaser_thread(out_iface: str):
    # Thread to dequeue packets, wait for their release time, and forward them.
    # Open AF_PACKET socket once — same approach as sender
    sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
    sock.bind((out_iface, 0))

    while True:
        try:
            release_time_ns, raw = pkt_queue.get(timeout=1.0)
        except queue.Empty:
            continue

        # Sleep most of the way (wake 1ms early)
        now_ns   = time.time_ns()
        sleep_ns = release_time_ns - now_ns - SPIN_EARLY_NS
        if sleep_ns > 0:
            time.sleep(sleep_ns / 1e9)

        # Busy-wait final 1ms for precision
        while time.time_ns() < release_time_ns:
            pass

        # Forward via AF_PACKET — no scapy overhead
        sock.send(raw)



def main():
    # Main function to parse arguments and start threads.
    parser = argparse.ArgumentParser(
        description='Hardware switch port model: hold-and-forward with target latency'
    )
    parser.add_argument('--in-iface',
                        required=True,
                        help='Interface to receive from (SW side)')
    parser.add_argument('--out-iface',
                        required=True,
                        help='Interface to forward to (receiver side)')
    parser.add_argument('--target-latency',
                        required=True,
                        type=float,
                        help='Target latency in milliseconds (fixed, models HW switch)')
    args = parser.parse_args()

    target_latency_ns = int(args.target_latency * 1e6)

    print(
        f'[helper] in={args.in_iface} out={args.out_iface} '
        f'target={args.target_latency}ms ({target_latency_ns}ns)',
        flush=True,
    )

    r = Thread(
        target = receiver_thread,
        args   = (args.in_iface, target_latency_ns),
        daemon = True,
        name   = 'receiver',
    )
    s = Thread(
        target = releaser_thread,
        args   = (args.out_iface,),
        daemon = True,
        name   = 'releaser',
    )

    r.start()
    s.start()
    r.join()


if __name__ == '__main__':
    main()
