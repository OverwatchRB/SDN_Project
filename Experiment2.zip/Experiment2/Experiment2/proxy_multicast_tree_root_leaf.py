#!/usr/bin/env python3

import argparse
import socket
import sys
from collections import deque
from scapy.all import Ether, sniff

ETYPE_INT = 0x1234
INT_HEADER_LEN = 24
ETH_DST_OFF = 0
ETH_SRC_OFF = 6
ETH_HDR_LEN = 14
IPV4_SRC_OFF = ETH_HDR_LEN + INT_HEADER_LEN + 12
IPV4_DST_OFF = ETH_HDR_LEN + INT_HEADER_LEN + 16
IPV4_CKSUM_OFF = ETH_HDR_LEN + INT_HEADER_LEN + 10
BCAST_MAC = 'ff:ff:ff:ff:ff:ff'

def mac_to_bytes(mac: str) -> bytes:
    return bytes(int(x, 16) for x in mac.split(':'))

def is_my_packet(raw_frame: bytearray, my_ip_bytes: bytes) -> bool:
    if len(raw_frame) < IPV4_SRC_OFF + 4:
        return False
    return raw_frame[IPV4_SRC_OFF:IPV4_SRC_OFF+4] == my_ip_bytes

def forward_frame(raw_frame: bytearray,
                  my_mac_bytes: bytes,
                  my_ip_bytes: bytes,
                  dst_mac: str,
                  dst_ip: str) -> bytearray:
    fwd = bytearray(raw_frame)
    fwd[ETH_DST_OFF:ETH_DST_OFF+6] = mac_to_bytes(dst_mac)
    fwd[ETH_SRC_OFF:ETH_SRC_OFF+6] = my_mac_bytes
    if dst_ip:
        fwd[IPV4_SRC_OFF:IPV4_SRC_OFF+4] = my_ip_bytes
        fwd[IPV4_DST_OFF:IPV4_DST_OFF+4] = socket.inet_aton(dst_ip)
        fwd[IPV4_CKSUM_OFF:IPV4_CKSUM_OFF+2] = b'\x00\x00'
    return fwd

class DedupSet:
    """Fixed-size sliding window of seen msg_ids."""
    def __init__(self, window=8192):
        self.window = window
        self.seen = set()
        self.order = deque()
    def check_and_mark(self, msg_id):
        if msg_id in self.seen:
            return False
        self.seen.add(msg_id)
        self.order.append(msg_id)
        if len(self.order) > self.window:
            old = self.order.popleft()
            self.seen.discard(old)
        return True

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--my-mac', required=True)
    parser.add_argument('--my-ip', required=True)
    parser.add_argument('--children-macs', required=True)
    parser.add_argument('--children-ips', required=True)
    parser.add_argument('--children-ifaces', required=True)
    parser.add_argument('--recv-ifaces', required=True, help='comma-separated interfaces to sniff on')
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--count', type=int, default=0)
    args = parser.parse_args()

    children_macs = args.children_macs.split(',')
    children_ips = args.children_ips.split(',')
    children_ifaces = args.children_ifaces.split(',')
    if not (len(children_macs) == len(children_ips) == len(children_ifaces)):
        raise ValueError('--children-* must have same number of entries')
    children = list(zip(children_macs, children_ips, children_ifaces))

    my_mac_bytes = mac_to_bytes(args.my_mac)
    my_ip_bytes = socket.inet_aton(args.my_ip)

    # Open raw sockets for all unique outgoing interfaces
    unique_out = set(iface for _, _, iface in children)
    raw_socks = {}
    for iface in unique_out:
        s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
        s.bind((iface, 0))
        raw_socks[iface] = s

    recv_ifaces = args.recv_ifaces.split(',')
    dedup = DedupSet()
    pkt_count = 0

    def handler(pkt):
        nonlocal pkt_count
        if Ether not in pkt or pkt[Ether].type != ETYPE_INT:
            return
        raw = bytearray(bytes(pkt))
        if is_my_packet(raw, my_ip_bytes):
            return
        # extract msg_id (bytes 20-21 of INT header, after Ethernet)
        if len(raw) < ETH_HDR_LEN + 22:
            return
        msg_id = int.from_bytes(raw[ETH_HDR_LEN+20:ETH_HDR_LEN+22], 'big')
        if not dedup.check_and_mark(msg_id):
            if args.debug:
                print(f'  Dropped duplicate msg_id {msg_id}', file=sys.stderr)
            return
        pkt_count += 1
        for dst_mac, dst_ip, iface in children:
            fwd = forward_frame(raw, my_mac_bytes, my_ip_bytes, dst_mac, dst_ip)
            raw_socks[iface].send(bytes(fwd))
            if args.debug:
                mode = f'OBS ip={dst_ip}' if dst_ip else 'direct'
                print(f'  [#{pkt_count}] -> {dst_mac} iface={iface} ({mode})', file=sys.stderr)

    print(f'[fast proxy] listening on {recv_ifaces}', file=sys.stderr)
    sniff_kwargs = dict(iface=recv_ifaces, prn=handler, store=False, promisc=True)
    if args.count > 0:
        sniff_kwargs['count'] = args.count
    try:
        sniff(**sniff_kwargs)
    except KeyboardInterrupt:
        pass
    for s in raw_socks.values():
        s.close()
    print(f'[fast proxy] Done. Forwarded {pkt_count} packets.', file=sys.stderr)

if __name__ == '__main__':
    main()
