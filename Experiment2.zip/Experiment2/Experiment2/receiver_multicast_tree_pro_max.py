#!/usr/bin/env python3

import argparse
import csv
import signal
import struct
import sys
import time
from collections import deque
from scapy.all import Ether, sniff

ETYPE_INT = 0x1234
INT_HDR_SIZE = 24
OFF_CUM_TOTAL = 2
OFF_CUM_QUEUE = 8
OFF_CUM_PROC = 14
OFF_MSG_ID = 20
AFTER_INT_TO_PAYLOAD = 20 + 8   # IPv4(20) + UDP(8)

buffer = []
args = None

class DedupSet:
    def __init__(self, window=8192):
        self.window = window
        self.seen = set()
        self.order = deque()
    def check_and_mark(self, msg_id):
        if msg_id in self.seen:
            return False
        self.seen.add(msg_id)
        self.order.append(msg_id)
        if len(self.order) > self.window:
            old = self.order.popleft()
            self.seen.discard(old)
        return True

def parse_packet(pkt, host_index):
    if Ether not in pkt:
        return None
    if pkt[Ether].type != ETYPE_INT:
        return None
    raw = bytes(pkt)[14:]   # skip Ethernet header
    if len(raw) < INT_HDR_SIZE + 20 + 8 + 8:
        return None
    cum_total = int.from_bytes(raw[OFF_CUM_TOTAL:OFF_CUM_TOTAL+6], 'big')
    cum_queue = int.from_bytes(raw[OFF_CUM_QUEUE:OFF_CUM_QUEUE+6], 'big')
    cum_proc  = int.from_bytes(raw[OFF_CUM_PROC:OFF_CUM_PROC+6], 'big')
    msg_id    = struct.unpack_from('>H', raw, OFF_MSG_ID)[0]
    payload = raw[INT_HDR_SIZE + AFTER_INT_TO_PAYLOAD:]
    if len(payload) < 8:
        return None
    send_ts = struct.unpack_from('>Q', payload, 0)[0]
    if send_ts == 0:
        return None
    recv_ts = int(time.time() * 1_000_000)
    e2e_us = recv_ts - send_ts
    if e2e_us < 0 or e2e_us > 60_000_000:
        return None
    return {
        'msg_id': msg_id,
        'recv_ts_us': recv_ts,
        'e2e_us': e2e_us,
        'cum_total_delay': cum_total,
        'cum_queue_delay': cum_queue,
        'cum_proc_delay': cum_proc,
        'host_index': host_index,
    }

def flush_to_csv():
    fieldnames = ['msg_id', 'recv_ts_us', 'e2e_us',
                  'cum_total_delay', 'cum_queue_delay', 'cum_proc_delay',
                  'host_index']
    with open(args.outfile, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(buffer)
    print(f"[receiver p{args.host_index}] Flushed {len(buffer)} rows to {args.outfile}", flush=True)

def handle_sigterm(signum, frame):
    print(f"\n[receiver p{args.host_index}] SIGTERM received — flushing {len(buffer)} packets to CSV ...", flush=True)
    flush_to_csv()
    sys.exit(0)

def main():
    global args, buffer
    parser = argparse.ArgumentParser()
    parser.add_argument('--host-index', type=int, required=True)
    parser.add_argument('--outfile', required=True)
    parser.add_argument('--recv-ifaces', required=True, help='comma-separated interfaces to sniff on')
    args = parser.parse_args()
    signal.signal(signal.SIGTERM, handle_sigterm)

    recv_ifaces = args.recv_ifaces.split(',')
    dedup = DedupSet()

    def handler(pkt):
        if Ether not in pkt or pkt[Ether].type != ETYPE_INT:
            return
        raw = bytes(pkt)
        if len(raw) < 14 + 22:
            return
        msg_id = int.from_bytes(raw[14+20:14+22], 'big')
        if not dedup.check_and_mark(msg_id):
            return   # duplicate, discard
        rec = parse_packet(pkt, args.host_index)
        if rec is not None:
            buffer.append(rec)

    print(f"[receiver p{args.host_index}] Starting.", flush=True)
    print(f"  recv_ifaces: {recv_ifaces}", flush=True)
    print(f"  outfile     : {args.outfile}", flush=True)
    print(f"  mode        : buffer in memory, flush on SIGTERM, dedup on msg_id", flush=True)

    try:
        sniff(iface=recv_ifaces, filter="ether proto 0x1234", prn=handler, store=False, promisc=True)
    except KeyboardInterrupt:
        print(f"\n[receiver p{args.host_index}] KeyboardInterrupt — flushing CSV ...")
        flush_to_csv()
        sys.exit(0)

if __name__ == '__main__':
    main()
