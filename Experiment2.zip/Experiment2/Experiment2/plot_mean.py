#!/usr/bin/env python3
"""
Usage:
    python3 plot_oml_mean.py --base . --out mean_h3d3.png --h-filter 3 --d-filter 3
    python3 plot_oml_mean.py --base . --out mean_h3d4.png --h-filter 3 --d-filter 4
"""

import os
import re
import glob
import argparse
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker


DEFAULT_BASE = os.path.expanduser(
    "~/tutorials/exercises/multicast/comparative/uniform/hedging"
)

STRATEGIES = ["root", "subtree_cover", "uniform"]

STRATEGY_STYLE = {
    "root":          {"color": "#d62728", "marker": "s", "label": "Root"},
    "subtree_cover": {"color": "#1f77b4", "marker": "o", "label": "Subtree Cover"},
    "uniform":       {"color": "#2ca02c", "marker": "^", "label": "Uniform"},
}

RE_FOLDER = re.compile(
    r"results_host_model"
    r"_h(?P<h>\d+)_d(?P<d>\d+)_k(?P<k>\d+)"
    r"_H(?P<H>\d+)"
    r"_(?P<placement>root|leaf|subtree_cover|uniform)"
    r"_spin\d+_delay[\d\.]+ms_var[\d\.]+ms"
    r"_c\d+_gap[\d\.]+ms_\d{8}_\d{6}"
)

RE_OML_MEAN = re.compile(r"OML.*?mean\s*:\s*([\d\.]+)\s*us", re.DOTALL)
RE_DWS_MEAN = re.compile(r"DWS.*?mean\s*:\s*([\d\.]+)\s*us", re.DOTALL)
RE_DWS_STD  = re.compile(r"DWS.*?std\s*:\s*([\d\.]+)\s*us",  re.DOTALL)
RE_OML_STD  = re.compile(r"OML.*?std\s*:\s*([\d\.]+)\s*us",  re.DOTALL)


def parse_summary_file(path):
    try:
        with open(path, "r") as f:
            text = f.read()
    except OSError:
        return None
    dws_mean = RE_DWS_MEAN.search(text)
    dws_std  = RE_DWS_STD.search(text)
    oml_mean = RE_OML_MEAN.search(text)
    oml_std  = RE_OML_STD.search(text)
    if not (dws_mean and dws_std and oml_mean and oml_std):
        return None
    return (float(dws_mean.group(1)), float(dws_std.group(1)),
            float(oml_mean.group(1)), float(oml_std.group(1)))


def parse_folder_name(folder_name):
    m = RE_FOLDER.match(folder_name)
    if m:
        return (int(m.group("h")), int(m.group("d")), int(m.group("k")),
                int(m.group("H")), m.group("placement"))
    return None

# ---------------------------------------------------------------------------
# Data collection — averages across runs
# ---------------------------------------------------------------------------

def collect_averaged(base_dir, filter_placements=None,
                     filter_h=None, filter_d=None, filter_H=None):
    """
    Returns dict: { placement: { k: (dws_mean, dws_std, oml_mean, oml_std) } }
    Averages across all runs for each (h, d, k, placement) combination.
    """
    result = {p: {} for p in STRATEGIES}
    all_dirs = glob.glob(os.path.join(base_dir, "results_host_model_*"))
    if not all_dirs:
        raise FileNotFoundError(
            f"No 'results_host_model_*' directories found under: {base_dir}"
        )

    groups = defaultdict(list)
    for dpath in all_dirs:
        basename = os.path.basename(dpath)
        parsed = parse_folder_name(basename)
        if not parsed:
            print(f"  [skip] Unrecognised dir: {basename}")
            continue
        h, d, k, H, placement = parsed
        if placement not in STRATEGIES:
            continue
        if filter_placements and placement not in filter_placements:
            continue
        if filter_h is not None and h != filter_h:
            continue
        if filter_d is not None and d != filter_d:
            continue
        if filter_H is not None and H != filter_H:
            continue
        stats = parse_summary_file(os.path.join(dpath, "summary.txt"))
        if stats is None:
            print(f"  [warn] No valid summary in: {basename}")
            continue
        groups[(k, placement)].append(stats)

    for (k, placement), runs in sorted(groups.items()):
        n = len(runs)
        avg = (
            sum(r[0] for r in runs) / n,
            sum(r[1] for r in runs) / n,
            sum(r[2] for r in runs) / n,
            sum(r[3] for r in runs) / n,
        )
        result[placement][k] = avg
        print(f"  k={k:2d}  {placement:15s}  "
              f"DWS={avg[0]:.1f} us  OML={avg[2]:.1f} us  "
              f"(avg of {n} run{'s' if n > 1 else ''})")

    return result

def plot(data, out_path):
    fig, axes = plt.subplots(1, 2, figsize=(14, 5), sharex=True)

    for placement in STRATEGIES:
        pdata = data[placement]
        if not pdata:
            continue
        ks        = sorted(pdata.keys())
        dws_means = [pdata[k][0] / 1000 for k in ks]
        oml_means = [pdata[k][2] / 1000 for k in ks]
        style     = STRATEGY_STYLE[placement]

        axes[0].plot(ks, dws_means, marker=style["marker"], color=style["color"],
                     linewidth=2, markersize=6, label=style["label"])
        axes[1].plot(ks, oml_means, marker=style["marker"], color=style["color"],
                     linewidth=2, markersize=6, label=style["label"])

    axes[0].set_title(
        "Per-message DWS\n(max − min recv timestamp across receivers)",
        fontsize=10
    )
    axes[1].set_title(
        "Per-message OML\n(max e2e latency across receivers)",
        fontsize=10
    )

    for ax in axes:
        ax.set_xlabel("Switch Budget (k)", fontsize=11)
        ax.set_ylabel("Duration (ms)", fontsize=10)
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
        ax.grid(True, linestyle="--", alpha=0.45)
        ax.legend(fontsize=9)

    plt.tight_layout()
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    print(f"\nPlot saved -> {out_path}")


def main():
    parser = argparse.ArgumentParser(
        description='Plot mean DWS and OML vs switch budget k'
    )
    parser.add_argument("--base",      default=DEFAULT_BASE,
                        help="Directory containing result folders")
    parser.add_argument("--out",       default="mean_oml_dws.png")
    parser.add_argument("--h-filter",  type=int, default=3)
    parser.add_argument("--d-filter",  type=int, default=3)
    parser.add_argument("--H-filter",  type=int, default=0)
    parser.add_argument("--placement", nargs="+", choices=STRATEGIES)
    args = parser.parse_args()

    print(f"Scanning: {args.base}\n")
    data = collect_averaged(
        args.base, args.placement,
        args.h_filter, args.d_filter, args.H_filter
    )

    total = sum(len(data[p]) for p in STRATEGIES)
    if total == 0:
        print("No data found. Exiting.")
        return

    plot(data, args.out)


if __name__ == "__main__":
    main()
