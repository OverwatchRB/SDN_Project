#include <core.p4>
#include <v1model.p4>

// Define types and headers for Ethernet, INT, IPv4, and UDP.
typedef bit<9>  egressSpec_t;
typedef bit<48> macAddr_t;

// Ethernet header with destination and source MAC addresses and EtherType.
header ethernet_t {
    macAddr_t dstAddr;
    macAddr_t srcAddr;
    bit<16>   etherType;
}

// INT header with hop count, cumulative delays, message ID, and reserved bits.
header int_t {
    bit<16> hop_cnt;
    bit<48> cum_total_delay;   // sum of (egress_ts - ingress_ts)
    bit<48> cum_queue_delay;   // sum of deq_timedelta
    bit<48> cum_proc_delay;    // sum of (total - queue)
    bit<16> msg_id;
    bit<16> reserved;
}

// IPv4 header with version, IHL, DSCP, total length, identification, flags, fragment offset,
// TTL, protocol, header checksum, source and destination addresses.
header ipv4_t {
    bit<4>  version;
    bit<4>  ihl;
    bit<8>  diffserv;
    bit<16> total_len;
    bit<16> identification;
    bit<3>  flags;
    bit<13> frag_offset;
    bit<8>  ttl;
    bit<8>  protocol;
    bit<16> hdr_checksum;
    bit<32> src_addr;
    bit<32> dst_addr;
}

// UDP header with source and destination ports, length, and checksum.
header udp_t {
    bit<16> src_port;
    bit<16> dst_port;
    bit<16> length;
    bit<16> checksum;
}

// Metadata struct to hold the ingress timestamp for calculating delays in the egress block.
struct metadata {
    bit<48> ingress_ts;
}

// Struct to hold all headers for parsing and processing.
struct headers {
    ethernet_t ethernet;
    int_t      int_hdr;
    ipv4_t     ipv4;
    udp_t      udp;
}

// Parser to extract headers from incoming packets. It first extracts the Ethernet header,
// then checks the EtherType to determine if it should parse an INT header (0x1234) or 
// an IPv4 header (0x0800). If an INT header is present, it is extracted before the IPv4 header.
parser MyParser(packet_in packet,
                out headers hdr,
                inout metadata meta,
                inout standard_metadata_t standard_metadata) {

    state start {
        packet.extract(hdr.ethernet);
        transition select(hdr.ethernet.etherType) {
            0x1234: parse_int;
            default: parse_ipv4;
        }
    }
    state parse_int {
        packet.extract(hdr.int_hdr);
        transition parse_ipv4;
    }
    state parse_ipv4 {
        packet.extract(hdr.ipv4);
        transition parse_udp;
    }
    state parse_udp {
        packet.extract(hdr.udp);
        transition accept;
    }
}

// VerifyChecksum control block (empty for now, can be extended to verify checksums if needed).
control MyVerifyChecksum(inout headers hdr, inout metadata meta) {
    apply { }
}

// Ingress control block that implements the forwarding logic. It defines three actions:
// 'drop' to mark the packet for dropping, 
// 'multicast' to set the multicast group for forwarding, and 
// 'mac_forward' to set the egress port for forwarding the packet.
// The 'mac_lookup' table matches on the destination MAC address and 
// applies the appropriate action based on the match. If the packet has a valid Ethernet header, 
// it applies the 'mac_lookup' table.
control MyIngress(inout headers hdr,
                  inout metadata meta,
                  inout standard_metadata_t standard_metadata) {

    action drop() {
        mark_to_drop(standard_metadata);
    }

    action multicast() {
        standard_metadata.mcast_grp = 1;
    }

    action mac_forward(egressSpec_t port) {
        standard_metadata.egress_spec = port;
    }

    table mac_lookup {
        key = { hdr.ethernet.dstAddr : exact; }
        actions = { multicast; mac_forward; drop; }
        size = 1024;
        default_action = multicast;
    }

    apply {
        meta.ingress_ts = standard_metadata.ingress_global_timestamp;
        if (hdr.int_hdr.isValid()) {
            hdr.int_hdr.hop_cnt = hdr.int_hdr.hop_cnt + 1;
        }
        if (hdr.ethernet.isValid()) {
            mac_lookup.apply();
        }
    }
}

// Egress control block that calculates the total, queueing, and processing delays for INT packets.
control MyEgress(inout headers hdr,
                 inout metadata meta,
                 inout standard_metadata_t standard_metadata) {

    action drop() {
        mark_to_drop(standard_metadata);
    }

    apply {
        // Avoid sending back to ingress port
        if (standard_metadata.egress_port == standard_metadata.ingress_port) {
            drop();
        }
        if (hdr.int_hdr.isValid()) {
            // Total per‑hop delay
            bit<48> total = standard_metadata.egress_global_timestamp - meta.ingress_ts;
            // Queueing delay (deq_timedelta is 32‑bit)
            bit<48> queue = (bit<48>) standard_metadata.deq_timedelta;
            // Processing delay = total - queue
            bit<48> proc = total - queue;

            hdr.int_hdr.cum_total_delay = hdr.int_hdr.cum_total_delay + total;
            hdr.int_hdr.cum_queue_delay = hdr.int_hdr.cum_queue_delay + queue;
            hdr.int_hdr.cum_proc_delay  = hdr.int_hdr.cum_proc_delay + proc;
        }
    }
}

// ComputeChecksum control block (empty for now, can be extended to compute checksums if needed).
control MyComputeChecksum(inout headers hdr, inout metadata meta) {
    apply { }
}

// Deparser control block that emits the headers back into the packet. It emits the Ethernet header first,
// then the INT header if it is valid (i.e., if the packet had an EtherType of 0x1234), 
// followed by the IPv4 and UDP headers. The payload is appended automatically by the bmv2 backend 
// after the headers are emitted.
control MyDeparser(packet_out packet, in headers hdr) {
    apply {
        packet.emit(hdr.ethernet);
        packet.emit(hdr.int_hdr);    // emits only if valid
        packet.emit(hdr.ipv4);
        packet.emit(hdr.udp);
        // payload is automatically emitted
    }
}

// Main control block that instantiates the parser, verify checksum, ingress, egress, 
// compute checksum, and deparser blocks.
V1Switch(MyParser(), MyVerifyChecksum(), MyIngress(), MyEgress(),
         MyComputeChecksum(), MyDeparser()) main;
