#!/usr/bin/env python3

"""
Usage:
    python3 proxy_multicast_tree_root_leaf.py \
        --my-mac         00:11:22:33:44:55 \
        --my-ip          192.168.1.100 \
        --children-macs   00:aa:bb:cc:dd:ee,00:ff:ee:dd:cc:bb \
        --children-ips    192.168.1.101,192.168.1.102 \
        --children-ifaces eth0,eth1 \
        --iface-in       eth2 \
        --debug \
        --count 100    
"""

# Imports and constants for a proxy multicast tree root/leaf implementation. 
# This script listens for packets on a specified interface, 
# checks if they are relevant to the proxy (based on the source IP), 
# and forwards them to child interfaces with appropriate modifications to the 
# Ethernet and IP headers. The script uses raw sockets for forwarding and Scapy for packet sniffing.
import argparse
import socket
import sys
from scapy.all import Ether, sniff

ETYPE_INT      = 0x1234
INT_HEADER_LEN = 24

ETH_DST_OFF    = 0
ETH_SRC_OFF    = 6
ETH_HDR_LEN    = 14

IPV4_SRC_OFF   = ETH_HDR_LEN + INT_HEADER_LEN + 12
IPV4_DST_OFF   = ETH_HDR_LEN + INT_HEADER_LEN + 16
IPV4_CKSUM_OFF = ETH_HDR_LEN + INT_HEADER_LEN + 10


# This function converts a MAC address string (e.g., "00:11:22:33:44:55") into its 
# corresponding byte representation.
def mac_to_bytes(mac: str) -> bytes:
    return bytes(int(x, 16) for x in mac.split(':'))

# This function checks if a given raw Ethernet frame is relevant to the proxy by comparing 
# the source IP address in the frame with the proxy's own IP address.
def is_my_packet(raw_frame: bytearray, my_ip_bytes: bytes) -> bool:
    if len(raw_frame) < IPV4_SRC_OFF + 4:
        return False
    return raw_frame[IPV4_SRC_OFF:IPV4_SRC_OFF + 4] == my_ip_bytes


# This function forwards a raw Ethernet frame to a specified child interface, 
# modifying the Ethernet and IP headers as needed. It rewrites the source and destination 
# MAC addresses, and if a destination IP is provided, it also rewrites the source and 
# destination IP addresses and zeroes the IP checksum.
def forward_frame(raw_frame: bytearray,
                  my_mac_bytes: bytes,
                  my_ip_bytes: bytes,
                  dst_mac: str,
                  dst_ip: str) -> bytearray:
    """
    Build a forwarded frame for one child.
    - Always rewrites src MAC to my_mac and dst MAC to dst_mac.
    - Only rewrites src/dst IP (and zeroes checksum) if dst_ip is non-empty
      (i.e. child is reached via OBS).
    - If dst_ip is empty (direct switch child), MAC rewrite is sufficient.
    """
    fwd = bytearray(raw_frame)
    fwd[ETH_DST_OFF:ETH_DST_OFF + 6] = mac_to_bytes(dst_mac)
    fwd[ETH_SRC_OFF:ETH_SRC_OFF + 6] = my_mac_bytes
    if dst_ip:
        fwd[IPV4_SRC_OFF:IPV4_SRC_OFF + 4] = my_ip_bytes
        fwd[IPV4_DST_OFF:IPV4_DST_OFF + 4] = socket.inet_aton(dst_ip)
        fwd[IPV4_CKSUM_OFF:IPV4_CKSUM_OFF + 2] = b'\x00\x00'
    return fwd


# The main function parses command-line arguments to configure the proxy, sets up
# raw sockets for forwarding, and starts sniffing for packets on the specified input interface. 
# For each relevant packet, it forwards it to the child interfaces according to the provided 
# configuration, while also logging the forwarding actions if debugging is enabled.
def main():
    parser = argparse.ArgumentParser(
        description='Proxy relay — per-child iface forwarding (root/leaf)'
    )
    parser.add_argument('--my-mac',           required=True)
    parser.add_argument('--my-ip',            required=True)
    parser.add_argument('--children-macs',    required=True,
                        help='Comma-separated MAC per child')
    parser.add_argument('--children-ips',     required=True,
                        help='Comma-separated IP per child; empty string '
                             'for direct switch children')
    parser.add_argument('--children-ifaces',  required=True,
                        help='Comma-separated iface per child; eth0 for OBS '
                             'path, ethX for direct switch children')
    parser.add_argument('--iface-in',         required=True,
                        help='Interface to sniff/receive on')
    parser.add_argument('--debug',            action='store_true')
    parser.add_argument('--count',            type=int, default=0)
    args = parser.parse_args()

    children_macs   = args.children_macs.split(',')
    children_ips    = args.children_ips.split(',')
    children_ifaces = args.children_ifaces.split(',')

    if not (len(children_macs) == len(children_ips) == len(children_ifaces)):
        raise ValueError(
            '--children-macs, --children-ips, --children-ifaces '
            'must all have the same number of entries'
        )

    children = list(zip(children_macs, children_ips, children_ifaces))

    my_mac_bytes = mac_to_bytes(args.my_mac)
    my_ip_bytes  = socket.inet_aton(args.my_ip)

    # Open one raw socket per unique outgoing interface
    unique_ifaces = set(iface for _, _, iface in children)
    raw_socks = {}
    for iface in unique_ifaces:
        s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
        s.bind((iface, 0))
        raw_socks[iface] = s

    print(f'[proxy {args.my_mac}]',                    file=sys.stderr)
    print(f'  my IP          : {args.my_ip}',           file=sys.stderr)
    print(f'  iface-in       : {args.iface_in}',        file=sys.stderr)
    print(f'  children:',                               file=sys.stderr)
    for mac, ip, iface in children:
        mode = f'OBS -> {ip}' if ip else 'direct (broadcast)'
        print(f'    {mac}  iface={iface}  {mode}',      file=sys.stderr)

    pkt_count = 0

    # This handler function is called for each packet sniffed on the input interface. 
    # It checks if the packet is an Ethernet frame with the expected type, and 
    # if it is relevant to the proxy (not originating from the proxy's own IP). 
    # If the packet is relevant, it forwards it to each child interface according 
    # to the configuration, while also logging the forwarding actions if debugging is enabled.
    def handler(pkt):
        nonlocal pkt_count

        if Ether not in pkt or pkt[Ether].type != ETYPE_INT:
            return

        raw = bytearray(bytes(pkt))

        if is_my_packet(raw, my_ip_bytes):
            return

        pkt_count += 1

        for dst_mac, dst_ip, iface in children:
            fwd = forward_frame(raw, my_mac_bytes, my_ip_bytes,
                                dst_mac, dst_ip)
            raw_socks[iface].send(bytes(fwd))

            if args.debug:
                mode = f'OBS ip={dst_ip}' if dst_ip else 'direct'
                print(f'  [#{pkt_count}] -> {dst_mac} iface={iface} ({mode})',
                      file=sys.stderr)

    print(f'  Sniffing on {args.iface_in} ...', file=sys.stderr)

    sniff_kwargs = dict(
        iface   = args.iface_in,
        prn     = handler,
        store   = False,
        promisc = True,
    )
    if args.count > 0:
        sniff_kwargs['count'] = args.count

    try:
        sniff(**sniff_kwargs)
    except KeyboardInterrupt:
        pass

    for s in raw_socks.values():
        s.close()
    print(f'[proxy {args.my_mac}] Done. Forwarded {pkt_count} packets.',
          file=sys.stderr)


if __name__ == '__main__':
    main()
