// ip_fwd.p4 - IP forwarding for OneBigSwitch (obs/s3)
// Handles packets with etherType=0x1234 (INT header present)
// and standard 0x0800 packets.
#include <core.p4>
#include <v1model.p4>

// Define types and headers for Ethernet, INT, IPv4, and UDP.
typedef bit<48> macAddr_t;
typedef bit<9>  egressSpec_t;

// Ethernet header with destination and source MAC addresses and EtherType.
header ethernet_t {
    macAddr_t dstAddr;
    macAddr_t srcAddr;
    bit<16>   etherType;
}

// INT header with hop count, cumulative delays, message ID, and reserved bits.
header int_t {
    bit<16> hop_cnt;
    bit<48> cum_total_delay;
    bit<48> cum_queue_delay;
    bit<48> cum_proc_delay;
    bit<16> msg_id;
    bit<16> reserved;
}

// IPv4 header with version, IHL, DSCP, total length, identification, flags, fragment offset, 
// TTL, protocol, header checksum, source and destination addresses.
header ipv4_t {
    bit<4>  version;
    bit<4>  ihl;
    bit<8>  diffserv;
    bit<16> totalLen;
    bit<16> identification;
    bit<3>  flags;
    bit<13> fragOffset;
    bit<8>  ttl;
    bit<8>  protocol;
    bit<16> hdrChecksum;
    bit<32> srcAddr;
    bit<32> dstAddr;
}

// UDP header with source and destination ports, length, and checksum.
header udp_t {
    bit<16> srcPort;
    bit<16> dstPort;
    bit<16> length;
    bit<16> checksum;
}

// Metadata struct (empty for now, can be extended as needed).
struct metadata { }

// Struct to hold all headers for parsing and processing.
struct headers {
    ethernet_t ethernet;
    int_t      int_hdr;
    ipv4_t     ipv4;
    udp_t      udp;
}

// Parser to extract headers from incoming packets. It first extracts the Ethernet header,
// then checks the EtherType to determine if it should parse an INT header (0x1234) 
// or an IPv4 header (0x0800). If an INT header is present, it is extracted before the IPv4 header.
parser MyParser(packet_in packet,
                out headers hdr,
                inout metadata meta,
                inout standard_metadata_t stdmeta) {
    state start {
        packet.extract(hdr.ethernet);
        transition select(hdr.ethernet.etherType) {
            0x1234: parse_int;
            0x0800: parse_ipv4;
            default: accept;
        }
    }
    state parse_int {
        packet.extract(hdr.int_hdr);
        transition parse_ipv4;
    }
    state parse_ipv4 {
        packet.extract(hdr.ipv4);
        transition select(hdr.ipv4.protocol) {
            17: parse_udp;
            default: accept;
        }
    }
    state parse_udp {
        packet.extract(hdr.udp);
        transition accept;
    }
}

// VerifyChecksum control block (empty for now, can be extended to verify checksums if needed).
control MyVerifyChecksum(inout headers hdr, inout metadata meta) { apply { } }

// Ingress control block that implements the forwarding logic. It defines two actions:
// 'forward' to set the egress port for forwarding the packet, and 'drop'
// to mark the packet for dropping. The 'ip_table' matches on the destination IP address and applies
// the appropriate action based on the match. If the packet has a valid IPv4 header, it applies the 'ip_table'.
control MyIngress(inout headers hdr,
                  inout metadata meta,
                  inout standard_metadata_t stdmeta) {
    action forward(egressSpec_t port) {
        stdmeta.egress_spec = port;
    }
    action drop() {
        mark_to_drop(stdmeta);
    }
    table ip_table {
        key = { hdr.ipv4.dstAddr: exact; }
        actions = { forward; drop; }
        size = 1024;
        default_action = drop();
    }
    apply {
        if (hdr.ipv4.isValid()) {
            ip_table.apply();
        }
    }
}

// Egress control block (empty for now, can be extended to modify packets before egress if needed).
control MyEgress(inout headers hdr, inout metadata meta,
                 inout standard_metadata_t stdmeta) { apply { } }

// ComputeChecksum control block (empty for now, can be extended to compute checksums if needed).
control MyComputeChecksum(inout headers hdr, inout metadata meta) { apply { } }

// Deparser control block that emits the headers back into the packet. It emits the Ethernet header first,
// then the INT header if it is valid (i.e., if the packet had an EtherType of 0x1234), 
// followed by the IPv4 and UDP headers. The payload is appended automatically by the bmv2 backend 
// after the headers are emitted.
control MyDeparser(packet_out packet, in headers hdr) {
    apply {
        packet.emit(hdr.ethernet);
        packet.emit(hdr.int_hdr);   // only emits if valid (0x1234 packets)
        packet.emit(hdr.ipv4);
        packet.emit(hdr.udp);
        // payload appended automatically by bmv2
    }
}

// Main control block that instantiates the parser, verify checksum, ingress, 
// egress, compute checksum, and deparser blocks.
V1Switch(MyParser(), MyVerifyChecksum(), MyIngress(), MyEgress(),
         MyComputeChecksum(), MyDeparser()) main;
