#!/usr/bin/env python3
"""
Usage:
    python3 receiver_multicast_tree_pro_max.py \
        --host-index 1  \
        --outfile    /tmp/rc_l3_p0.csv \
        --iface      eth0
"""

# Imports and constants for a receiver in a multicast tree implementation. 
# This script listens for packets on a specified interface, parses the packets to extract 
# relevant information (such as message ID, timestamps, and cumulative delays), and 
# buffers this information in memory. The buffered data is flushed to a CSV file when the 
# script receives a SIGTERM signal or is interrupted by the user. \
# The script uses Scapy for packet sniffing and struct for parsing binary data from the packets.
import argparse
import csv
import signal
import struct
import sys
import time
from scapy.all import Ether, sniff


ETYPE_INT            = 0x1234
INT_HDR_SIZE         = 24
OFF_CUM_TOTAL        = 2
OFF_CUM_QUEUE        = 8
OFF_CUM_PROC         = 14
OFF_MSG_ID           = 20
AFTER_INT_TO_PAYLOAD = 20 + 8   # IPv4(20) + UDP(8)

buffer    = []   # list of dicts, one per received packet
args      = None

# This function parses a received packet to extract relevant information such as 
# message ID, timestamps, and cumulative delays. It checks if the packet is an Ethernet frame 
# with the expected type, and if it contains the necessary headers and payload.
# If the packet is valid, it returns a dictionary with the extracted information; otherwise, 
# it returns None.
def parse_packet(pkt, host_index):
    if Ether not in pkt:
        return None
    if pkt[Ether].type != ETYPE_INT:
        return None

    raw = bytes(pkt)[14:]   # skip Ethernet header

    if len(raw) < INT_HDR_SIZE + 20 + 8 + 8:
        return None

    cum_total = int.from_bytes(raw[OFF_CUM_TOTAL : OFF_CUM_TOTAL+6], 'big')
    cum_queue = int.from_bytes(raw[OFF_CUM_QUEUE : OFF_CUM_QUEUE+6], 'big')
    cum_proc  = int.from_bytes(raw[OFF_CUM_PROC  : OFF_CUM_PROC +6], 'big')
    msg_id    = struct.unpack_from('>H', raw, OFF_MSG_ID)[0]

    payload = raw[INT_HDR_SIZE + AFTER_INT_TO_PAYLOAD:]
    if len(payload) < 8:
        return None

    send_ts = struct.unpack_from('>Q', payload, 0)[0]
    if send_ts == 0:
        return None

    recv_ts = int(time.time() * 1_000_000)
    e2e_us  = recv_ts - send_ts

    if e2e_us < 0 or e2e_us > 60_000_000:
        return None

    return {
        'msg_id'          : msg_id,
        'recv_ts_us'      : recv_ts,
        'e2e_us'          : e2e_us,
        'cum_total_delay' : cum_total,
        'cum_queue_delay' : cum_queue,
        'cum_proc_delay'  : cum_proc,
        'host_index'      : host_index,
    }


# This function flushes the buffered packet information to a CSV file. It writes the data 
# to the specified output file with appropriate field names. After flushing, 
# it prints a message indicating how many rows were flushed and to which file. 
# This function is called when the script receives a SIGTERM signal or is interrupted by the user 
# to ensure that all collected data is saved before exiting.
def flush_to_csv():
    fieldnames = ['msg_id', 'recv_ts_us', 'e2e_us',
                  'cum_total_delay', 'cum_queue_delay', 'cum_proc_delay',
                  'host_index']
    with open(args.outfile, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(buffer)
    print(f"[receiver p{args.host_index}] "
          f"Flushed {len(buffer)} rows to {args.outfile}", flush=True)


# This signal handler is called when the script receives a SIGTERM signal. 
# It prints a message indicating that a SIGTERM was received and that it is flushing the 
# buffered data to CSV.
def handle_sigterm(signum, frame):
    print(f"\n[receiver p{args.host_index}] "
          f"SIGTERM received — flushing {len(buffer)} packets to CSV ...",
          flush=True)
    flush_to_csv()
    sys.exit(0)


# The main function parses command-line arguments to configure the receiver, sets up a 
# signal handler for SIGTERM, and starts sniffing for packets on the specified interface.
# For each received packet, it calls the handler function to parse the packet and buffer the 
# relevant information. If the user interrupts the script with a KeyboardInterrupt, 
# it also flushes the buffered data to CSV before exiting.
def main():
    global args

    parser = argparse.ArgumentParser()
    parser.add_argument('--host-index', type=int, required=True)
    parser.add_argument('--outfile',    required=True)
    parser.add_argument('--iface',      default='eth0')
    args = parser.parse_args()

    signal.signal(signal.SIGTERM, handle_sigterm)

    print(f"[receiver p{args.host_index}] Starting.", flush=True)
    print(f"  iface   : {args.iface}", flush=True)
    print(f"  outfile : {args.outfile}", flush=True)
    print(f"  mode    : buffer in memory, flush on SIGTERM", flush=True)

    def handler(pkt):
        rec = parse_packet(pkt, args.host_index)
        if rec is not None:
            buffer.append(rec)

    try:
        sniff(
            iface   = args.iface,
            filter  = "ether proto 0x1234",
            prn     = handler,
            store   = False,
            promisc = True,
        )
    except KeyboardInterrupt:
        print(f"\n[receiver p{args.host_index}] KeyboardInterrupt — flushing CSV ...")
        flush_to_csv()
        sys.exit(0)


if __name__ == '__main__':
    main()
