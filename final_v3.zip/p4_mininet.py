# Import necessary modules from Mininet and Python standard library 
# to define custom host and switch classes for a P4-based network simulation. 
# The P4Host class extends the default Host class to configure the host's network interface 
# and disable IPv6. The P4Switch class extends the default Switch class to start a 
# P4 software switch using the provided binary and JSON configuration, 
# manage its lifecycle, and handle its interfaces. The code also includes methods to
# check if the switch has started successfully by verifying the availability of the Thrift server.
from mininet.net import Mininet
from mininet.node import Switch, Host
from mininet.log import setLogLevel, info, error, debug
from mininet.moduledeps import pathCheck
from sys import exit
import os
import tempfile
import socket

# Custom host class that configures the host's network interface and disables IPv6.
class P4Host(Host):

    # This function is called when the host is configured. 
    # It renames the default interface to "eth0", disables offloading features (rx, tx, sg) 
    # using ethtool, and disables IPv6 on all interfaces. It returns the result of the 
    # parent class's config method.
    def config(self, **params):
        r = super(Host, self).config(**params)

        self.defaultIntf().rename("eth0")

        for off in ["rx", "tx", "sg"]:
            cmd = "/sbin/ethtool --offload eth0 %s off" % off
            self.cmd(cmd)

        # disable IPv6
        self.cmd("sysctl -w net.ipv6.conf.all.disable_ipv6=1")
        self.cmd("sysctl -w net.ipv6.conf.default.disable_ipv6=1")
        self.cmd("sysctl -w net.ipv6.conf.lo.disable_ipv6=1")

        return r
    
    # This function prints a description of the host, including its name and 
    # the details of its default interface (name, IP address, and MAC address).
    def describe(self):
        print("**********")
        print(self.name)
        print("default interface: %s\t%s\t%s" %(
            self.defaultIntf().name,
            self.defaultIntf().IP(),
            self.defaultIntf().MAC()
        ))
        print("**********")

# Custom switch class that manages a P4 software switch. It includes methods to start and stop 
# the switch, attach and detach interfaces, and check if the switch has started successfully 
# by verifying the availability of the Thrift server.
class P4Switch(Switch):
    """P4 virtual switch"""
    device_id = 0
    
    # This function initializes the P4Switch instance with the provided parameters, including the
    # switch binary path, JSON configuration path, Thrift port, and other options. 
    # It checks the validity of the provided paths, sets up logging, and assigns a
    # unique device ID for the switch. The device ID is used to manage multiple switches and 
    # their corresponding log files.
    def __init__(self, name, sw_path = None, json_path = None,
                 thrift_port = None,
                 pcap_dump = False,
                 log_console = False,
                 verbose = False,
                 device_id = None,
                 enable_debugger = False,
                 **kwargs):
        Switch.__init__(self, name, **kwargs)
        assert(sw_path)
        assert(json_path)
        # make sure that the provided sw_path is valid
        pathCheck(sw_path)
        # make sure that the provided JSON file exists
        if not os.path.isfile(json_path):
            error("Invalid JSON file.\n")
            exit(1)
        self.sw_path = sw_path
        self.json_path = json_path
        self.verbose = verbose
        logfile = "/tmp/p4s.{}.log".format(self.name)
        self.output = open(logfile, 'w')
        self.thrift_port = thrift_port
        self.pcap_dump = pcap_dump
        self.enable_debugger = enable_debugger
        self.log_console = log_console
        if device_id is not None:
            self.device_id = device_id
            P4Switch.device_id = max(P4Switch.device_id, device_id)
        else:
            self.device_id = P4Switch.device_id
            P4Switch.device_id += 1
        self.nanomsg = "ipc:///tmp/bm-{}-log.ipc".format(self.device_id)

    # This class method is a placeholder for any setup that might be needed before 
    # starting the switch.
    @classmethod
    def setup(cls):
        pass

    # This function checks if the switch has started successfully by verifying the availability 
    # of the Thrift server.
    def check_switch_started(self, pid):
        """While the process is running (pid exists), we check if the Thrift
        server has been started. If the Thrift server is ready, we assume that
        the switch was started successfully. This is only reliable if the Thrift
        server is started at the end of the init process"""
        while True:
            if not os.path.exists(os.path.join("/proc", str(pid))):
                return False
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.settimeout(0.5)
                result = sock.connect_ex(("localhost", self.thrift_port))
            finally:
                sock.close()
            if result == 0:
                return  True

    # This function starts the P4 switch by constructing the command-line arguments based on the 
    # provided parameters, executing the command to start the switch, 
    # and checking if it started successfully by verifying the availability of the Thrift server.
    # It also logs the command and the switch's PID for debugging purposes.
    def start(self, controllers):
        "Start up a new P4 switch"
        info("Starting P4 switch {}.\n".format(self.name))
        args = [self.sw_path]
        for port, intf in self.intfs.items():
            if not intf.IP():
                args.extend(['-i', str(port) + "@" + intf.name])
        if self.pcap_dump:
            args.append("--pcap")
            # args.append("--useFiles")
        if self.thrift_port:
            args.extend(['--thrift-port', str(self.thrift_port)])
        if self.nanomsg:
            args.extend(['--nanolog', self.nanomsg])
        args.extend(['--device-id', str(self.device_id)])
        P4Switch.device_id += 1
        args.append(self.json_path)
        if self.enable_debugger:
            args.append("--debugger")
        if self.log_console:
            args.append("--log-console")
        logfile = "/tmp/p4s.{}.log".format(self.name)
        info(' '.join(args) + "\n")

        pid = None
        with tempfile.NamedTemporaryFile() as f:
            # self.cmd(' '.join(args) + ' > /dev/null 2>&1 &')
            self.cmd(' '.join(args) + ' >' + logfile + ' 2>&1 & echo $! >> ' + f.name)
            pid = int(f.read())
        debug("P4 switch {} PID is {}.\n".format(self.name, pid))
        if not self.check_switch_started(pid):
            error("P4 switch {} did not start correctly.\n".format(self.name))
            exit(1)
        info("P4 switch {} has been started.\n".format(self.name))

    # This function stops the P4 switch by sending a kill signal to the process and 
    # waiting for it to terminate.
    def stop(self):
        "Terminate P4 switch."
        self.output.flush()
        self.cmd('kill %' + self.sw_path)
        self.cmd('wait')
        self.deleteIntfs()

    # The attach and detach functions are placeholders for connecting and disconnecting data ports.
    def attach(self, intf):
        "Connect a data port"
        assert(0)

    def detach(self, intf):
        "Disconnect a data port"
        assert(0)
    
    # This function disables IPv6 on a specific interface by executing the appropriate sysctl command.
    def disable_ipv6(self, intf):
        "Disable ipv6 on a specific interface"
        self.cmd("sysctl -w net.ipv6.conf.%s.disable_ipv6=1" % intf)
